<?php
require_once 'header.php';
require_once 'navigration.php';
     require_once 'connection/manage.php';
    $objects = new Manage();
  
    if(isset($_GET['delete'])){
        $delete_id = $_GET['delete'];
        $objects->deleteofmanage($delete_id);
    }
      $result = $objects->selectmanage();
?>
<section>
    <div class="container">
        <div class="row">
            <div class="well">
                <h2 class="text-center"> Publish Blog List </h2>
                <table class="table table-bordered table-hover">
                    <tr style="background: green; color: #fff; ">
                        <th> Serial No. </th>
                        <th> Heading </th>
                        <th> Reporter Name </th>
                        <th> Details </th>
                        <th> Publish </th>
                        <th> Action </th>
                    </tr>
                    <?php 
                    $i=1;
                    while ($rows = mysqli_fetch_assoc($result)){
                    ?>
                    <tr>
                        <td> <?php echo $i++;?> </td>
                        <td> <?php echo $rows['headline']; ?> </td>
                        <td> <?php echo $rows['reportername']; ?> </td>
                        <td> <?php echo $rows['details']; ?> </td>
                        <td> <?php echo $rows['action']; ?> </td>
                        <td> 
                        <a href=""class="btn btn-success btn-xs"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
                        <a href="?delete=<?php echo $rows['manage_id']; ?>"class="btn btn-danger btn-xs"><i class="fa fa-trash-o" aria-hidden="true"></i></a>
                        </td>
                    </tr>
                    <?php } ?>
                    
                </table>
            </div>
        </div>
    </div>
</section>
<?php

require_once 'footer.php';
?>
        