<footer>
    <p class="text-center bg-info" style="padding: 10px;"> @2018 News Paper Blog </p>
</footer>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>

</body>
</html>