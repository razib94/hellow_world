<?php

class Image {
       private $con;
    public function __construct() {
        $dbhost = "localhost";
        $dbuser = "root";
        $dbpass = "";
        $dbname = "blog_management";
        $this->con = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
        if (!$this->con) {
            echo 'This is Problem of Database and Server' . mysqli_error($this->con);
        }
    }
    public function add_image_info($data){
       $image_file = $_FILES['image']['name'];
       $direction = 'image/';
       $image_url = $direction.$image_file;
       $image_type = pathinfo($image_file,PATHINFO_EXTENSION);
       $image_size = $_FILES['image']['size'];
       $check = getimagesize($_FILES['image']['tmp_name']);
       if($check){
           if(file_exists($image_url)){
               die("This file already exist. Please try another one");
           } else {
               if($image_size > 500000){
                   die("File Size is too large");
               } else {
                   if($image_type != 'jpg' && $image_type !='png'){
                       die("File Type is not Valid. Please use JPG or PNG");
                   } else {
                              move_uploaded_file($_FILES['image']['tmp_name'], $image_url);
                              $sql = "INSERT INTO images (image) VALUES ('$image_url')";
                              mysqli_query($this->con, $sql);
                              echo 'Image Upload is Succesfull';
                   }
               }
           }
       } else {
           die("The file You upload is not an image. Please upload a valid Image file!");
       }
    }
    public function add_image_selected(){
        $selected = "SELECT * FROM images";
        $res = mysqli_query($this->con, $selected);
        if($res){
            return $res;
        } else {
            echo 'This is Problem';
        }
    }
        public function add_image_selected_idby_id(){
        $selected = "SELECT * FROM images ORDER BY id_image DESC limit 0,3";
        $res = mysqli_query($this->con, $selected);
        if($res){
            return $res;
        } else {
            echo 'This is Problem';
        }
    }
}
