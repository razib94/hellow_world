<?php

class Manage {

    private $con;

    public function __construct() {
        $dbhost = "localhost";
        $dbuser = "root";
        $dbpass = "";
        $dbname = "blog_management";
        $this->con = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
        if (!$this->con) {
            echo 'This is Problem of Database and Server' . mysqli_error($this->con);
        }
    }
    public function manageinsert($data){
        $insert = "INSERT INTO manage(headline,reportername, details,action) VALUES ('$data[headline]','$data[reportname]','$data[details]','$data[action]')";
        $totalinsert = mysqli_query($this->con, $insert);
        if($totalinsert){
            echo 'this is Ok';
        } else {
            echo 'this is not ok';
        }
    }
    public function selectmanage(){
        $select = "SELECT * FROM manage ORDER BY manage_id DESC";
        $result = mysqli_query($this->con, $select);
         if ($result) {
            return $result;
        } else {
            echo 'Problem';
        }
    }
        public function selectmanageinduvisul(){
        $select = "SELECT * FROM manage WHERE action=1 ORDER BY manage_id DESC limit 0,6";
        $result = mysqli_query($this->con, $select);
         if ($result) {
            return $result;
        } else {
            echo 'Problem';
        }
    }
    public function selectallaplication($ids){
        $select = "SELECT * FROM manage WHERE manage_id ='$ids'";
        $result = mysqli_query($this->con, $select);
         if ($result) {
            return $result;
        } else {
            echo 'Problem';
        }
    }
        public function deleteofmanage($id_delete){
        $select = "DELETE FROM manage WHERE manage_id ='$id_delete'";
        $result = mysqli_query($this->con, $select);
         if ($result) {
           
        } else {
            echo 'Problem';
        }
    }

}
