<?php

class Login {
    private $con;
    public function __construct() {
        $dbhost = "localhost";
        $dbuser = "root";
        $dbpass = "";
        $dbname = "blog_management";
        $this->con = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
        if(!$this->con){
            echo 'This is Problem of Database and Server'. mysqli_error($this->con);
        }
    }
    public function admin_login_check($data){
        $password = md5($data['password']);
        $select = "SELECT * FROM user WHERE username = '$data[username]' AND password='$password'";
        $result_select = mysqli_query($this->con, $select);
        $admininfo = mysqli_fetch_assoc($result_select);
        if($admininfo){
             session_start();
            $_SESSION['id']= $admininfo['id'];
            $_SESSION['username']= $admininfo['username'];
            header("location:dashboard.php");
            
        } else {
             $message = "Your Email and Passwoard is Invalid";
            return $message;
        }
        
    }
    public function logout(){
        unset($_SESSION['id']);
        unset($_SESSION['username']);
        header("Location: index.php");
    }
}
