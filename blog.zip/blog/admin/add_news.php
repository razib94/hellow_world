<?php
require_once 'header.php';
require_once 'navigration.php';
if(isset($_POST['submit'])){
    require_once 'connection/manage.php';
    $objects = new Manage();
    $objects->manageinsert($_POST);
}
?>

<section>
    <div class="container">
        <div class="row">
            <div class="well">
                <form class="form-horizontal" action="" method="POST">
                    <div class="form-group">
                        <label for="inputEmail3" class="col-sm-2 control-label"> Head Line </label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" name="headline" id="inputEmail3" placeholder="Headline">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="inputPassword3" class="col-sm-2 control-label"> Reporter Name </label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" name="reportname" id="inputPassword3" placeholder="Reporter Name">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="inputPassword3" class="col-sm-2 control-label"> Details </label>
                        <div class="col-sm-10">
                            <textarea rows="5" class="form-control" name="details"></textarea>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="inputPassword3" class="col-sm-2 control-label"> Publish Status </label>
                        <div class="col-sm-10">
                            <select class="form-control" name="action">
                                <option>-----Select Your Status-----</option>
                                <option value="1">Publish</option>
                                <option value="0">Unpublish </option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-10">
                            <button type="submit" name="submit" class="btn btn-info">Submit</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
<?php

require_once 'footer.php';
?>
        