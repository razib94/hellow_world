<?php 
session_start();
if(isset($_SESSION['username'])){
    if($_SESSION['username'] != NULL){
        header("Location:dashboard.php");
    }
}
if(isset($_POST['submit'])){
require_once 'connection/login.php';
$objects = new Login();
$objects->admin_login_check($_POST);
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        <title> Blog </title>

        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/style.css" rel="stylesheet">
        <link rel="stylesheet" href="css/font-awesome.min.css">
    </head>
    <body>
        <div class = "container">
            <div class="wrapper">

                <form action="" method="post" name="Login_Form" class="form-signin"> 
                    <div class="row text-center bol"><i class="fa fa-circle"></i></div>
                    <div>
                        <h1 class="text-center"> Login </h1>
                    </div>
                    <hr class="spartan">
                    <div class="input-group">
                        <span class="input-group-addon" id="sizing-addon1">
                            <i class="fa fa-user"></i>
                        </span>
                        <input type="text" class="form-control" name="username" placeholder="Username" required="" autofocus="" />
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon" id="sizing-addon1">
                            <i class="fa fa-lock"></i>
                        </span>
                        <input type="password" class="form-control" name="password" placeholder="Password" required=""/>         	  
                    </div>
                    <button class="btn btn-lg btn-success btn-block"  name="submit"  type="Submit"> Login </button>  			
                </form>			
            </div>
        </div>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <script src="js/bootstrap.min.js"></script>

    </script>
</body>
</html>
