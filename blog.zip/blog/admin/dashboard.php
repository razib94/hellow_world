<?php

require_once 'header.php';
require_once 'navigration.php';
?>

<section>
    <div class="container">
        lkdsafjlaskd 
    </div>
</section>
<?php

require_once 'footer.php';
?>
        