<?php
require_once 'header.php';
require_once 'navigration.php';
if(isset($_POST['submit'])){
    require_once 'connection/image.php';
    $objects = new Image();
    $objects->add_image_info($_POST);
}
?>
<section>
    <div class="container">
        <div class="row">
            <div class="well">
                <form class="form-horizontal" action="" method="POST" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="inputPassword3" class="col-sm-2 control-label"> Image Upload </label>
                        <div class="col-sm-10" >
                            <input type="file" class="form-control" name="image"/>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-10">
                            <button type="submit" name="submit" class="btn btn-info form-control">Submit</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
<?php

require_once 'footer.php';
?>
        