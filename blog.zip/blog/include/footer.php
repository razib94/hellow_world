 <div class="footer-section">
            <div class="footer">
                <div class="container">
                    <div class="col-md-4 footer-one">
                        <div class="foot-logo">
                            <h3 style="color:#fff;"><b> Blog Management </b></h3>
                        </div> 

                        <p>Providing Life Changing Experiences Through Education. Class That Fit Your Busy Life. Closer to Home
                        </p>
                        <div class="social-icons"> 
                            <a href="https://www.facebook.com/"><i id="social-fb" class="fa fa-facebook-square fa-3x social"></i></a>
                            <a href="https://twitter.com/"><i id="social-tw" class="fa fa-twitter-square fa-3x social"></i></a>
                            <a href="https://plus.google.com/"><i id="social-gp" class="fa fa-google-plus-square fa-3x social"></i></a>
                            <a href="mailto:bootsnipp@gmail.com"><i id="social-em" class="fa fa-envelope-square fa-3x social"></i></a>
                        </div>
                    </div>
                    <div class="col-md-2 footer-two">
                        <h5>Quick Links</h5>
                        <ul>
                            <li><a href="#"> About Us</a> </li>
                            <li><a href="#"> Our News</a> </li>
                            <li><a href="#"> Our Services</a> </li>
                            <li><a href="#"> Contact Us</a> </li>
                        </ul>

                    </div>
                    <div class="col-md-2 footer-three">
                        <h5>Services</h5>
                        <ul>
                            <li><a href="#"> About Us</a> </li>
                            <li><a href="#"> Our News</a> </li>
                            <li><a href="#"> Our Services</a> </li>
                            <li><a href="#"> Contact Us</a> </li>
                        </ul>

                    </div>
                    <div class="col-md-4 footer-four">
                        <h5>Contact Us</h5>
                        <img src="http://iacademy.mikado-themes.com/wp-content/uploads/2017/05/footer-img-1.png">  

                    </div>






                    <div class="clearfix"></div>
                </div>
            </div>

        </div>
        <div class="footer-bottom">
            <div class="container">
                <div class="row">
                    <div class="col-sm-6 ">
                        <div class="copyright-text">
                            <p>CopyRight © 2017 Blog Management All Rights Reserved</p>
                        </div>
                    </div> <!-- End Col -->
                    <div class="col-sm-6  ">
                        <div class="copyright-text pull-right">
                            <p> <a href="#">Home</a> | <a href="#">Privacy</a> |<a href="#">Terms & Conditions</a> | <a href="#">Refund Policy</a> </p>
                        </div>					

                    </div> <!-- End Col -->
                </div>
            </div>
        </div>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <script src="js/bootstrap.js"></script>
    </body>
</html>