<?php 
require_once 'include/header.php';
require_once 'include/navigration.php';
     require_once 'admin/connection/manage.php';
      require_once 'admin/connection/image.php';
    $objects = new Manage();
    $result = $objects->selectmanageinduvisul();
    $obsject_image = new Image();
    $result_image = $obsject_image->add_image_selected_idby_id();
    ?>
        <div class="container main">
    <hr>
    <div class="row">
        <div class="col-sm-9">
            <div class="main-box">
                <img src="admin/image/happy-fit-people.jpg" class="img-responsive" width="100%">
		    <div class="subtitle">
		        <span>কেমন হবে প্রযুক্তিময় ভালোবাসা?</span>
		    </div>
		</div>
        </div>
        <div class="row col-sm-3">

            <div class="main-box">
                <img src="admin/image/falgun.jpg" class="img-responsive" width="100%">
		    <div class="subtitle">
		        <span>Subtitle</span>
		    </div>
		</div>
             <div class="main-box">
                 <img src="admin/image/download (1).jpg" class="img-responsive" width="100%">
		    <div class="subtitle">
		        <span>Subtitle</span>
		    </div>
		</div>
        </div>
    </div>
</div>
        <div class="blog">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-lg-offset-3 text-center">  
                        <h2><span class="ion-minus"></span>---- Blog Posts ---- <span class="ion-minus"></span></h2>
                        </div> 
                </div>  
                <div class="row">
                        <?php while ($rows = mysqli_fetch_assoc($result)){?>
                    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12" data-aos="fade-right">
                        <div class="card">
                            
                            <div class="card-block">
                                <h3 class="text-left"><strong> <?php echo $rows['headline']; ?> </strong><br><small> <?php echo $rows['reportername']; ?>  </small></h3>
                                     <img class="card-img-top" src="https://images.pexels.com/photos/39811/pexels-photo-39811.jpeg?h=350&auto=compress&cs=tinysrgb" alt="" width="100%">
                                <p class="text-justify"><?php echo mb_substr($rows['details'],0,120); ?> </p>
                               
                                <span class="text-left" style="padding-right: 100px;"> 21.01.2018 </span>
                                 <a class="btn btn-success" href="blog_details.php?id=<?php echo $rows['manage_id']; ?>">Read More...</a>
                            </div>
                        </div>
                    </div>
                        <?php } ?>

                </div>

            </div>
        </div>
<div class="container" style="margin-bottom: 25px;">
	<div class="row">
		<h1 class="text-center mr10"> Important Event </h1>
	<?php 
            while ($row = mysqli_fetch_assoc($result_image)){
        ?>
	    <div class="col-md-4 col-sm-4 wrapper-banner">
                <a class="banner mr10" href="#"><img src="admin/<?php echo $row['image']; ?>" alt=""></a>
	       
	   </div>
            <?php } ?>
	</div>
</div>
       <?php require_once 'include/footer.php';?>