<?php 
require_once 'include/header.php';
require_once 'include/navigration.php';
     require_once 'admin/connection/manage.php';
     $id = $_GET['id'];
    $objects = new Manage();
    $result = $objects->selectallaplication($id);
?>

        
        <div class="container">
        </div>
        <div class="blog">
            <div class="container">
                <div class="row">
                        <?php $rows = mysqli_fetch_assoc($result);?>
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" data-aos="fade-right">
                        <div class="card text-center">
                            <!-- <img class="card-img-top" src="https://images.pexels.com/photos/39811/pexels-photo-39811.jpeg?h=350&auto=compress&cs=tinysrgb" alt="" width="100%">-->
                            <div class="card-block">
                                <h3 class="text-left"><strong> <?php echo $rows['headline']; ?> </strong><br><small> <?php echo $rows['reportername']; ?>  </small></h3>

                                <p class="text-justify"><?php echo $rows['details']; ?> </p>
                            </div>
                        </div>
                    </div>
               

                </div>

            </div>
        </div>
       <?php require_once 'include/footer.php';?>