<?php include 'admin_information/header.php'; 
 include 'admin_information/navigration.php';
 require 'db_config/service.php';
     $obj_service = new Service();
    if(isset($_POST['submit'])){
    $obj_service->serviceinfo($_POST);
} ?>
<div class="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="#"> Courses </a>
            </li>
            <li class="breadcrumb-item active"> Service Information </li>
        </ol>
        <form class="form-horizontal" action="" method="POST" enctype="multipart/form-data">

            <div class="form-group">
                <label for="inputEmail3" class="col-sm-3 control-label"> Service Name </label>
                <div class="col-sm-4">
                    <input type="text" class="form-control" id="inputEmail3" name="service_name"  placeholder="Enter Your Sevice Name" required="">
                </div>
            </div>
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-3 control-label"> Service Information </label>
                <div class="col-sm-4">
                    <textarea class="form-control" type="textarea" name="servic_info" id="message" placeholder="Enter Your Inforamtion" maxlength="140" rows="7"></textarea>                 
                </div>
            </div>
             <div class="form-group">
                <label for="inputEmail3" class="col-sm-3 control-label"> Service Fee </label>
                <div class="col-sm-4">
                    <input type="text" class="form-control" id="inputEmail3" name="service_fee"  placeholder="Enter Your Service Fee" required="">
                </div>
            </div>
             <div class="form-group">
                <label for="inputEmail3" class="col-sm-3 control-label"> Service Picture </label>
                <div class="col-sm-4">
                    <input type="file" class="form-control" id="inputEmail3" name="service_image" required="">
                </div>
            </div>
            <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
                    <button type="submit" class="btn btn-primary" name="submit"> Submit </button>
                </div>
            </div>
        </form>

        <?php include 'admin_information/footer.php'; ?>
   