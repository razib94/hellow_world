<?php include 'admin_information/header.php'; 
 include 'admin_information/navigration.php';
require  'db_config/banner.php';
$obj_banner_view = new Banner();
if (isset($_GET['delete'])) {
    $id_delete = $_GET['delete'];
    $deleteinfo = $obj_banner_view->deletebannerinfo($id_delete);
}
$select = $obj_banner_view->selectedinfo();
?> 
<div class="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="#"> Top Bar Offer </a>
            </li>
            <li class="breadcrumb-item active"> Offer Message </li>
        </ol>

<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
              <thead>
                <tr>
                  <th> ID </th>
                  <th>Message Info </th>
                  <th>Publish Date</th>
                  <th>Action</th>
             
                </tr>
              </thead>
             <?php while($rows = mysqli_fetch_assoc($select)){ ?>
              <tr>
                  <td> <?php echo $rows['banner_id']; ?></td>
                  <td> <?php echo $rows['banner_name']; ?></td>
                  <td><img src="<?php echo $rows['banner_image']; ?>" alt="banner" height="50" width="50"/> </td>
                  <td> <a href="edit_banner.php?id=<?php echo $rows['banner_id']; ?>" class="btn btn-info"> Edit </a> <a href="?delete=<?php echo $rows['banner_id']; ?>" class="btn btn-danger"> Delete </a> </td>
              </tr>
              <?php } ?>
              <tbody>
              </tbody>
            </table>
    <?php include 'admin_information/footer.php'; ?>