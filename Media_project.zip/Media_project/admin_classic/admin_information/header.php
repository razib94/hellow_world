<?php 
session_start();
$admin_id = $_SESSION['email'];
if(!$admin_id){
    header("Location: index.php");
}
if(isset($_GET['action'])) {
    if($_GET['action'] == 'logout')
        include 'db_config/logout.php';
        $obj = new Logout();
        $obj->logout_check();
    }

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <link rel="icon" href="../image/logo/main_logo.png" type="image/png" sizes="16x16">
  <title>Media Admin Information </title>
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
  <link href="css/sb-admin.css" rel="stylesheet">
</head>
<body class="fixed-nav sticky-footer bg-dark" id="page-top">