<?php include 'admin_information/header.php'; 
 include 'admin_information/navigration.php';
 require  'db_config/service.php';
$obj_service = new Service();

if (isset($_GET['delete'])) {
    $id_delete = $_GET['delete'];
    $deleteinfo = $obj_service->deleteserviceinfo($id_delete);
}
$select = $obj_service->selectedinfo();
 ?> 
<div class="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="#"> Top Bar Offer </a>
            </li>
            <li class="breadcrumb-item active"> Offer Message </li>
        </ol>
<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
              <thead>
                <tr>
                  <th> ID </th>
                  <th> Service Name </th>
                  <th> Service Information </th>
                  <th> Service Fee </th>
                  <th> Image </th>
                  <th> Action </th>
                </tr>
              </thead>
              <?php while($rows = mysqli_fetch_assoc($select)){ ?>
              <tr>
                  <td> <?php echo $rows['service_id']; ?> </td>
                  <td> <?php echo $rows['service_name']; ?> </td>
                  <td> <?php echo $rows['service_info']; ?></td>
                  <td> <?php echo $rows['service_fee']; ?> </td>
                   <td><img src="images/<?php echo $rows['service_image']; ?>" alt="image" height="50" width="50"/> </td>
                   <td> <a href="edit_service.php?id=<?php echo $rows['service_id']; ?>" class="btn btn-info"> Edit </a> <a href="?delete=<?php echo $rows['service_id']; ?>" class="btn btn-danger"> Delete </a> </td>
              </tr>
              <?php } ?>
              <tbody>
              </tbody>
            </table>
    <?php include 'admin_information/footer.php'; ?>