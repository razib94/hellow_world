<?php include 'admin_information/header.php'; 
 include 'admin_information/navigration.php';
require  'db_config/top.php';
$top_obj = new Top(); 
if (isset($_GET['delete'])) {
    $id_delete = $_GET['delete'];
    $deleteinfo = $top_obj->deletetopinfo($id_delete);
}
$data_select = $top_obj->selectedinfo();
?> 
<div class="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="#"> Top Bar Offer </a>
            </li>
            <li class="breadcrumb-item active"> Offer Message </li>
        </ol>

<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
              <thead>
                <tr>
                  <th> ID </th>
                  <th>Message Info </th>
                  <th>Publish Date</th>
                  <th>Action</th>
             
                </tr>
              </thead>
             <?php while($rows = mysqli_fetch_assoc($data_select)){ ?>
              <tr>
                  <td> <?php echo $rows['offer_id']; ?></td>
                  <td> <?php echo $rows['offer_message']; ?></td>
                  <td> <?php echo $rows['published']; ?></td>
                  <td> <a href="top_edit.php?id=<?php echo $rows['offer_id']; ?>" class="btn btn-info"> Edit </a> <a href="?delete=<?php echo $rows['offer_id']; ?>" class="btn btn-danger"> Delete </a> </td>
              </tr>
              <?php } ?>
              <tbody>
              </tbody>
            </table>
    <?php include 'admin_information/footer.php'; ?>