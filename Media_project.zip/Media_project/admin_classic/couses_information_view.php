<?php include 'admin_information/header.php'; 
 include 'admin_information/navigration.php';
 require  'db_config/course.php';
$obj_courses = new Course();

if (isset($_GET['delete'])) {
    $id_delete = $_GET['delete'];
    $deleteinfo = $obj_courses->deletecourseinfo($id_delete);
}
$select = $obj_courses->selectedinfo();
 ?> 
<div class="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="#"> Top Bar Offer </a>
            </li>
            <li class="breadcrumb-item active"> Offer Message </li>
        </ol>
<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
              <thead>
                <tr>
                  <th> ID </th>
                  <th> Courses Name </th>
                  <th> Message </th>
                  <th> Outline</th>
                  <th> Courses Duration </th>
                  <th> Courses Fee </th>
                  <th> Courses Class </th>
                  <th> Image </th>
                  <th> Action </th>
                </tr>
              </thead>
              <?php while($rows = mysqli_fetch_assoc($select)){ ?>
              <tr>
                  <td> <?php echo $rows['courses_id']; ?> </td>
                  <td> <?php echo $rows['course_name']; ?> </td>
                  <td> <?php echo $rows['courses_info']; ?></td>
                  <td> <?php echo $rows['courses_outline']; ?></td>
                  <td> <?php echo $rows['courses_duration']; ?> </td>
                  <td> <?php echo $rows['courses_fee']; ?> </td>
                  <td> <?php echo $rows['courses_class']; ?> </td>
                   <td><img src="images/<?php echo $rows['image']; ?>" alt="banner" height="50" width="50"/> </td>
                   <td> <a href="course_edit.php?id=<?php echo $rows['courses_id']; ?>" class="btn btn-info"> Edit </a> <a href="?delete=<?php echo $rows['courses_id']; ?>" class="btn btn-danger"> Delete </a> </td>
              </tr>
              <?php } ?>
              <tbody>
              </tbody>
            </table>
    <?php include 'admin_information/footer.php'; ?>