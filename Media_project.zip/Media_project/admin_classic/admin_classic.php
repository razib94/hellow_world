<?php include 'admin_information/header.php'; ?>
  <?php    include 'admin_information/navigration.php'; ?>
    <div class="content-wrapper">
    <div class="container-fluid">
    <?php
           include 'admin_information/dashboard.php';
           include 'admin_information/footer.php';
  ?>
   
