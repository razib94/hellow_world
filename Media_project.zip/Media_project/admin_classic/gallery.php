
<?php include 'admin_information/header.php'; 
 include 'admin_information/navigration.php';
 require  'db_config/gallery.php';
      $obj_gallery = new Gallery();
if(isset($_POST['submit'])){
 $obj_gallery->galleryinfo($_POST); 
}
?>
<div class="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="#"> Gallery </a>
            </li>
            <li class="breadcrumb-item active"> Gallery Information </li>
        </ol>
             <form class="form-horizontal" action="" method="POST" enctype="multipart/form-data">

            <div class="form-group">
                <label for="inputEmail3" class="col-sm-3 control-label"> Image Name </label>
                <div class="col-sm-4">
                    <input type="text" class="form-control" id="inputEmail3" name="image_name"  placeholder="Image Name " required="">
                </div>
            </div>
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-3 control-label"> Gallery Picture </label>
                <div class="col-sm-4">
                    <input type="file" class="form-control" id="inputEmail3" name="image" required="">
                </div>
            </div>
            <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
                    <button type="submit" class="btn btn-primary" name="submit"> Submit </button>
                </div>
            </div>
        </form>
        <?php include 'admin_information/footer.php'; ?>
   