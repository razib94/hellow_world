<?php include 'admin_information/header.php'; ?>
<?php include 'admin_information/navigration.php';
if(isset($_POST['submit'])){
    require  'db_config/top.php';
 $top_obj = new Top();
 $top = $top_obj->topinfo($_POST);  
}
?>

<div class="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="#"> Top Bar Offer </a>
            </li>
            <li class="breadcrumb-item active"> Offer Message </li>
        </ol>
        <form class="form-horizontal" action="" method="POST">

            <div class="form-group">
                <label for="inputEmail3" class="col-sm-3 control-label"> Top Bar Message Offer </label>
                <div class="col-sm-4">
                    <input type="text" class="form-control" id="inputEmail3" name="offer"  placeholder="Top Bar Message Offer" required="">
                </div>
            </div>
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-3 control-label"> Publish Date </label>
                <div class="col-sm-4">
                    <input type="date" class="form-control" id="inputEmail3" name="date"  placeholder="Top Bar Message Offer" required="">
                </div>
            </div>
            <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
                    <button type="submit" class="btn btn-primary" name="submit"> Submit </button>
                </div>
            </div>
        </form>
       
        <?php include 'admin_information/footer.php'; ?>
   