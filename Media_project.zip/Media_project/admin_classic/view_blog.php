<?php include 'admin_information/header.php'; 
 include 'admin_information/navigration.php';
 require  'db_config/blog.php';
$obj_blog = new Blog();
if (isset($_GET['delete'])) {
    $id_delete = $_GET['delete'];
    $deleteinfo = $obj_blog->deletebloginfo($id_delete);
}
$selects = $obj_blog->selectedinfo();
?>
<div class="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="#"> Top Bar Offer </a>
            </li>
            <li class="breadcrumb-item active"> Offer Message </li>
        </ol>

<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
              <thead>
                <tr>
                  <th> ID </th>
                  <th>Title </th>
                  <th>Details</th>
                  <th>Image</th>
                  <th>Action</th>
             
                </tr>
              </thead>
          <?php while ($rows = mysqli_fetch_assoc($selects)){ ?>
              <tr>
                  <td> <?php echo $rows['blog_id']; ?> </td>
                  <td> <?php echo $rows['title']; ?>  </td>
                  <td> <?php echo $rows['details']; ?>  </td>
                  <td><img src="<?php echo $rows['image']; ?>" alt="banner" height="50" width="50"/> </td>
                  <td> <a href="edit_blog.php?id= <?php echo $rows['blog_id']; ?>" class="btn btn-info"> Edit </a> <a href="?delete=<?php echo $rows['blog_id']; ?>" class="btn btn-danger"> Delete </a> </td>
              </tr>
          <?php } ?>
              <tbody>
              </tbody>
            </table>
    <?php include 'admin_information/footer.php'; ?>
