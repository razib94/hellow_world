<?php include 'admin_information/header.php'; 
 include 'admin_information/navigration.php';
 require  'db_config/blog.php';
 $id = $_GET['id'];
      $obj_blog = new Blog();
      $blog = $obj_blog->update_edit_blog_by_id($id);
      $result = mysqli_fetch_assoc($blog);
if(isset($_POST['submit'])){
 $insert= $obj_blog->updateblog($_POST);
}
 ?>
<div class="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="#"> Courses </a>
            </li>
            <li class="breadcrumb-item active"> Blog Information </li>
        </ol>
        <form class="form-horizontal" action="" method="POST" enctype="multipart/form-data">

            <div class="form-group">
                <label for="inputEmail3" class="col-sm-3 control-label"> Blog Title </label>
                <div class="col-sm-4">
                    <input type="text" class="form-control" id="inputEmail3" name="blog_title" value="<?php echo $result['title']; ?>" >
                    <input type="hidden" class="form-control" id="inputEmail3" name="blog_id" value="<?php echo $result['blog_id']; ?>" >
                </div>
            </div>
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-3 control-label"> Blog Information </label>
                <div class="col-sm-4">
                    <textarea class="form-control" type="textarea" name="blog_info" id="message" placeholder="Message" maxlength="140" rows="7"><?php echo $result['details']; ?></textarea>                 
                </div>
            </div>
             <div class="form-group">
                <label for="inputEmail3" class="col-sm-3 control-label"> Image </label>
                <div class="col-sm-4">
                    <input type="file" class="form-control" id="inputEmail3" name="file" required="">
                </div>
            </div>
            <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
                    <button type="submit" class="btn btn-primary" name="submit"> Submit </button>
                </div>
            </div>
        </form>

        <?php include 'admin_information/footer.php'; ?>
   