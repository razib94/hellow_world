
<?php include 'admin_information/header.php'; 
 include 'admin_information/navigration.php';
 $id = $_GET['id'];
 require 'db_config/course.php';
     $obj_courses = new Course();
     $result = $obj_courses->update_edit_course_by_id($id);
     $row = mysqli_fetch_assoc($result);
     if(isset($_POST['submit'])){
 $obj_courses->updatecourse($_POST);
}
 ?>
<div class="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="#"> Courses </a>
            </li>
            <li class="breadcrumb-item active"> Couses Information </li>
        </ol>
        <form class="form-horizontal" action="" method="POST" enctype="multipart/form-data">

            <div class="form-group">
                <label for="inputEmail3" class="col-sm-3 control-label"> Courses Name </label>
                <div class="col-sm-4">
                    <input type="text" class="form-control" id="inputEmail3" name="course_name"  value="<?php echo $row['course_name']; ?>">
                    <input type="hidden" class="form-control" id="inputEmail3" name="course_id"  value="<?php echo $row['courses_id']; ?>">
                </div>
            </div>
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-3 control-label"> Courses Information </label>
                <div class="col-sm-4">
                    <textarea class="form-control" type="textarea" name="course_info" id="message" placeholder="Message" maxlength="140" rows="7"><?php echo $row['courses_info']; ?></textarea>                 
                </div>
            </div>
             <div class="form-group">
                <label for="inputEmail3" class="col-sm-3 control-label"> Courses Outline </label>
                <div class="col-sm-4">
                    <textarea class="form-control" type="textarea" id="message" name="outline" placeholder="outline" maxlength="140" rows="7"><?php echo $row['courses_outline']; ?></textarea>
                                       
                </div>
            </div>
             <div class="form-group">
                <label for="inputEmail3" class="col-sm-3 control-label"> Courses Duration </label>
                <div class="col-sm-4">
                    <input type="text" class="form-control" id="inputEmail3" name="duration" value="<?php echo $row['courses_duration']; ?>">
                </div>
            </div>
             <div class="form-group">
                <label for="inputEmail3" class="col-sm-3 control-label"> Courses Fee </label>
                <div class="col-sm-4">
                    <input type="text" class="form-control" id="inputEmail3" name="fee"  value="<?php echo $row['courses_fee']; ?>">
                </div>
            </div>
             <div class="form-group">
                <label for="inputEmail3" class="col-sm-3 control-label"> Courses Class </label>
                <div class="col-sm-4">
                    <input type="text" class="form-control" id="inputEmail3" name="class"  value="<?php echo $row['courses_class']; ?>">
                </div>
            </div>
             <div class="form-group">
                <label for="inputEmail3" class="col-sm-3 control-label"> Banner Picture </label>
                <div class="col-sm-4">
                    <input type="file" class="form-control" id="inputEmail3" name="file" required="">
                </div>
            </div>
            <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
                    <button type="submit" class="btn btn-primary" name="submit"> Submit </button>
                </div>
            </div>
        </form>

        <?php include 'admin_information/footer.php'; ?>
   