<?php 
if(isset($_POST['login'])){
require 'db_config/admin.php';
$object = new Admin();
$message = $object->admin_check_login($_POST);
}
include 'login/header.php';
?>

  <div class="container">
    <div class="card card-login mx-auto mt-5">
        <div class="card-header bg-primary"><h3 class="font_color text-center">Media Admin </h3></div>
      <div class="card-body">
          <form action="" method="post">
              <h5 class="text-danger"> <?php if(isset($message)){  echo $message; }?></h5>
          <div class="form-group">
            <label for="exampleInputEmail1">Email address</label>
            <input class="form-control" id="exampleInputEmail1" type="email" name="email" aria-describedby="emailHelp" placeholder="Enter email">
          </div>
          <div class="form-group">
            <label for="exampleInputPassword1">Password</label>
            <input class="form-control" id="exampleInputPassword1" name="password" type="password" placeholder="Password">
          </div>
          <div class="form-group">
            <div class="form-check">
              <label class="form-check-label">
                <input class="form-check-input" type="checkbox"> Remember Password</label>
            </div>
          </div>
            <input type="submit" name="login" class="btn btn-primary btn-block" value="Login"/>
        </form>
        <div class="text-center">
          <a class="d-block small mt-3" href="register.php">Register an Account</a>
          <a class="d-block small" href="forgot-password.php">Forgot Password?</a>
        </div>
      </div>
    </div>
  </div>
 <?php 
include 'login/footer.php';
?>