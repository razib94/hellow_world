<?php
class Banner {
    private $con;
    public function __construct() {
        $datahost = "localhost";
        $datauser = "root";
        $datapass = "";
        $database = "media_vision_institute";
        $this->con = mysqli_connect($datahost, $datauser, $datapass, $database);
        if (!$this->con) {
            die('Database and Server not Found' . mysqli_error($this->con));
        }
    }

    public function bannerinfo($input) {
         $image_url = $this->add_image_info();
        $sta = "INSERT INTO banner(banner_name, banner_image) VALUES ('$input[image_name]','$image_url')";
        $result = mysqli_query($this->con, $sta);
        if ($result) {
            ?>
<script type="javascript">
    window.alert("Are You Sure");
</script>
            <?php

        } else {
            echo 'Student information data is not Saved';
        }
    }

    public function selectedinfo() {
        $select = "SELECT * FROM banner";
        $result = mysqli_query($this->con, $select);
        if ($result) {
            return $result;
        } else {
            echo 'Problem';
        }
    }

    public function update_edit_banner_by_id($course_id) {
        $select = "SELECT * FROM banner WHERE banner_id = '$course_id'";
        $result = mysqli_query($this->con, $select);
        if ($result) {
            return $result;
        } else {
            echo 'Problem';
        }
    }

    public function updatebanner($data_id) {
        $update = "UPDATE banner SET banner_name='$data_id[image_name]',banner_image='$data_id[file]' WHERE banner_id='$data_id[banner_id]'";
        $updatesql = mysqli_query($this->con, $update);
        if ($updatesql) {
  
        } else {
            echo 'Student information data is not Saved';
        }
    }

    public function deletebannerinfo($id_delete) {
        $delete = "DELETE FROM banner WHERE banner_id='$id_delete'";
        $result = mysqli_query($this->con, $delete);
        if ($result) {
           $message='Student Information is Delete';
            return $message;
        } else {
            echo 'Problem';
        }
    }

     public function add_image_info(){
       $image_file = $_FILES['image']['name'];
       $direction = 'images/';
       $image_url = $direction.$image_file;
       $image_type = pathinfo($image_file,PATHINFO_EXTENSION);
       $image_size = $_FILES['image']['size'];
       $check = getimagesize($_FILES['image']['tmp_name']);
       if($check){
           if(file_exists($image_url)){
               die("This file already exist. Please try another one");
           } else {
               if($image_size > 500000){
                   die("File Size is too large");
               } else {
                   if($image_type != 'jpg' && $image_type !='png'){
                       die("File Type is not Valid. Please use JPG or PNG");
                   } else {
                              move_uploaded_file($_FILES['image']['tmp_name'], $image_url);
                              return $image_url;
                   }
               }
           }
       } else {
           die("The file You upload is not an image. Please upload a valid Image file!");
       }
    }
    public function selectedinfoby() {
        $select = "SELECT * FROM banner ORDER BY banner_id DESC limit 3";
        $result = mysqli_query($this->con, $select);
        if ($result) {
            return $result;
        } else {
            echo 'Problem';
        }
    }

}
