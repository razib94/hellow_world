<?php

class Top {

    private $con;

    public function __construct() {
        $datahost = "localhost";
        $datauser = "root";
        $datapass = "";
        $database = "media_vision_institute";
        $this->con = mysqli_connect($datahost, $datauser, $datapass, $database);
        if (!$this->con) {
            die('Database and Server not Found' . mysqli_error($this->con));
        }
    }

    public function topinfo($input) {
        $sta = "INSERT INTO offer_message(offer_message, published) VALUES ('$input[offer]','$input[date]')";
        $result = mysqli_query($this->con, $sta);
        if ($result) {
            ?>
            <script type="javascript">
                window.alert("Are You Sure");
            </script>
            <?php

        } else {
            echo 'Student information data is not Saved';
        }
    }

    public function selectedinfo() {
        $select = "SELECT * FROM offer_message";
        $result = mysqli_query($this->con, $select);
        if ($result) {
            return $result;
        } else {
            echo 'Problem';
        }
    }

    public function update_edit_top_by_id($offer_id) {
        $select = "SELECT * FROM offer_message WHERE offer_id = '$offer_id'";
        $result = mysqli_query($this->con, $select);
        if ($result) {
            return $result;
        } else {
            echo 'Problem';
        }
    }

    public function updatetop($data_id) {
        $update = "UPDATE offer_message SET offer_message='$data_id[offer]',published='$data_id[date]' WHERE offer_id='$data_id[offer_id]'";
        $updatesql = mysqli_query($this->con, $update);
        if ($updatesql) {
            
        } else {
            echo 'Student information data is not Saved';
        }
    }

    public function deletetopinfo($id_delete) {
        $delete = "DELETE FROM offer_message WHERE offer_id='$id_delete'";
        $result = mysqli_query($this->con, $delete);
        if ($result) {
            $message = 'Student Information is Delete';
            return $message;
        } else {
            echo 'Problem';
        }
    }

}
