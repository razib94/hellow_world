<?php

class Gallery {

    private $con;

    public function __construct() {
        $datahost = "localhost";
        $datauser = "root";
        $datapass = "";
        $database = "media_vision_institute";
        $this->con = mysqli_connect($datahost, $datauser, $datapass, $database);
        if (!$this->con) {
            die('Database and Server not Found' . mysqli_error($this->con));
        }
    }

    public function galleryinfo($input) {
        $image_urls = $this->add_image_info();
        $sta = "INSERT INTO gallery (name, image) VALUES ('$input[image_name]','$image_urls')";
        $result = mysqli_query($this->con, $sta);
        if ($result) {
            ?>
            <script type="javascript">
                window.alert("Are You Sure");
            </script>
            <?php

        } else {
            echo 'Student information data is not Saved';
        }
    }

    public function selectedinfo() {
        $select = "SELECT * FROM gallery";
        $result = mysqli_query($this->con, $select);
        if ($result) {
            return $result;
        } else {
            echo 'Problem';
        }
    }
      public function selectedinfoby() {
        $select = "SELECT * FROM gallery ORDER BY gallery_id DESC limit 12";
        $result = mysqli_query($this->con, $select);
        if ($result) {
            return $result;
        } else {
            echo 'Problem';
        }
    }

    public function update_edit_gallery_by_id($gallery_id) {
        $select = "SELECT * FROM gallery WHERE gallery_id = '$gallery_id'";
        $result = mysqli_query($this->con, $select);
        if ($result) {
            return $result;
        } else {
            echo 'Problem';
        }
    }

    public function updatetop($data_id) {
        $update = "UPDATE gallery SET name='$data_id[image_name]',image='$data_id[file]' WHERE gallery_id='$data_id[gallery_id]'";
        $updatesql = mysqli_query($this->con, $update);
        if ($updatesql) {
            
        } else {
            echo 'Student information data is not Saved';
        }
    }

    public function deletegalleryinfo($id_delete) {
        $delete = "DELETE FROM gallery WHERE gallery_id='$id_delete'";
        $result = mysqli_query($this->con, $delete);
        if ($result) {
            $message = 'Student Information is Delete';
            return $message;
        } else {
            echo 'Problem';
        }
    }
     public function add_image_info(){
       $image_file = $_FILES['image']['name'];
       $direction = 'images/';
       $image_url = $direction.$image_file;
       $image_type = pathinfo($image_file,PATHINFO_EXTENSION);
       $image_size = $_FILES['image']['size'];
       $check = getimagesize($_FILES['image']['tmp_name']);
       if($check){
           if(file_exists($image_url)){
               die("This file already exist. Please try another one");
           } else {
               if($image_size > 500000){
                   die("File Size is too large");
               } else {
                   if($image_type != 'jpg' && $image_type !='png'){
                       die("File Type is not Valid. Please use JPG or PNG");
                   } else {
                              move_uploaded_file($_FILES['image']['tmp_name'], $image_url);
                              return $image_url;
                   }
               }
           }
       } else {
           die("The file You upload is not an image. Please upload a valid Image file!");
       }
    }


}
