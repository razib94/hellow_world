<?php

class Admin {
    private $conn;
    public function __construct() {
        $host = 'localhost';
        $user = 'root';
        $password = '';
        $database = 'media_vision_institute';
        $this->conn = mysqli_connect($host, $user, $password, $database);
        if(!$this->conn){
            die("Query Problem".mysqli_errno($this->conn));
        }
    }
    /* Register Insert to Logic */
    public function data_insert($data){
        $sql = "INSERT INTO admin (first_name, last_name, email, password, confirm_password) VALUES ('$data[first]','$data[last]','$data[email]',md5('$data[password]'),md5('$data[con_password]'))";
        mysqli_query($this->conn, $sql);
        if(mysqli_query($this->conn, $sql)){
            $message= "Data is Successfully";
            header("Location:register.php");
        } else {
            //$message = "Data is not Input Succesfully";
            header("Location:index.php");
        }
    }
    public function admin_check_login($value){
        $user = $value['email'];
        $password = md5($value['password']);
        $select = "SELECT * FROM admin WHERE email='$user' AND password= '$password'";
        $result = mysqli_query($this->conn, $select);
        if($result){
        $admin_info = mysqli_fetch_assoc($result);
        if($admin_info){
            session_start();
            $_SESSION['email'] = $admin_info['email'];
            $_SESSION['id'] = $admin_info['id'];
            header("Location:admin_classic.php");
        } else {
            $message = "Invalid Your Email and Password";
            return $message;
        }
    
    } else {

    die("Query Problem".mysqli_errno($this->conn));
}
 
}
 
}
