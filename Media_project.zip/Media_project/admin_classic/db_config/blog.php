<?php

class Blog {

    private $con;

    public function __construct() {
        $datahost = "localhost";
        $datauser = "root";
        $datapass = "";
        $database = "media_vision_institute";
        $this->con = mysqli_connect($datahost, $datauser, $datapass, $database);
        if (!$this->con) {
            die('Database and Server not Found' . mysqli_error($this->con));
        }
    }

    public function bloginfo($input) {
        $image_url = $this->add_image_info();
        $sta = "INSERT INTO blog(title, image, details) VALUES ('$input[blog_title]','$image_url','$input[blog_info]')";
        $result = mysqli_query($this->con, $sta);
        if ($result) {
            ?>
            <script type="javascript">
                window.alert("Are You Sure");
            </script>
            <?php

        } else {
            echo 'Student information data is not Saved';
        }
    }

    public function selectedinfo() {
        $select = "SELECT * FROM blog";
        $result = mysqli_query($this->con, $select);
        if ($result) {
            return $result;
        } else {
            echo 'Problem';
        }
    }
    
    public function selectedinfoby() {
        $select = "SELECT * FROM blog ORDER BY blog_id DESC limit 4";
        $result = mysqli_query($this->con, $select);
        if ($result) {
            return $result;
        } else {
            echo 'Problem';
        }
    }

    public function update_edit_blog_by_id($blog_id) {
        $select = "SELECT * FROM blog WHERE blog_id = '$blog_id'";
        $result = mysqli_query($this->con, $select);
        if ($result) {
            return $result;
        } else {
            echo 'Problem';
        }
    }

    public function updateblog($data_id) {
        $update = "UPDATE blog SET title='$data_id[blog_title]',image='$data_id[file]',details='$data_id[blog_info]' WHERE blog_id='$data_id[blog_id]'";
        $updatesql = mysqli_query($this->con, $update);
        if ($updatesql) {
            
        } else {
            echo 'Student information data is not Saved';
        }
    }

    public function deletebloginfo($id_delete) {
        $delete = "DELETE FROM blog WHERE blog_id='$id_delete'";
        $result = mysqli_query($this->con, $delete);
        if ($result) {
            $message = 'Student Information is Delete';
            return $message;
        } else {
            echo 'Problem';
        }
    }
public function add_image_info(){
       $image_file = $_FILES['image']['name'];
       $direction = 'images/';
       $image_url = $direction.$image_file;
       $image_type = pathinfo($image_file,PATHINFO_EXTENSION);
       $image_size = $_FILES['image']['size'];
       $check = getimagesize($_FILES['image']['tmp_name']);
       if($check){
           if(file_exists($image_url)){
               die("This file already exist. Please try another one");
           } else {
               if($image_size > 500000){
                   die("File Size is too large");
               } else {
                   if($image_type != 'jpg' && $image_type !='png'){
                       die("File Type is not Valid. Please use JPG or PNG");
                   } else {
                              move_uploaded_file($_FILES['image']['tmp_name'], $image_url);
                              return $image_url;
                   }
               }
           }
       } else {
           die("The file You upload is not an image. Please upload a valid Image file!");
       }
    }


}
