<?php

class Service {
    
    private $con;
    public function __construct() {
        $datahost = "localhost";
        $datauser = "root";
        $datapass = "";
        $database = "media_vision_institute";
        $this->con = mysqli_connect($datahost, $datauser, $datapass, $database);
        if (!$this->con) {
            die('Database and Server not Found' . mysqli_error($this->con));
        }
    }
    public function serviceinfo($input) {
        $sta = "INSERT INTO service(service_name,service_info,service_fee,service_image) VALUES ('$input[service_name]','$input[servic_info]','$input[service_fee]','$input[service_image]')";
        $result = mysqli_query($this->con, $sta);
        if ($result) {
            ?>
<script type="javascript">
    window.alert("Are You Sure");
</script>
            <?php

        } else {
            echo 'Student information data is not Saved';
        }
    }

    public function selectedinfo() {
        $select = "SELECT * FROM service";
        $result = mysqli_query($this->con, $select);
        if ($result) {
            return $result;
        } else {
            echo 'Problem';
        }
    }


    public function updateservice($data_id) {
        $update = "UPDATE service SET service_name='$data_id[service_name]',service_info='$data_id[servic_info]',service_fee='$data_id[service_fee]',service_image='$data_id[service_image]' WHERE service_id='$data_id[service_id]'";
        $updatesql = mysqli_query($this->con, $update);
        if ($updatesql) {
  
        } else {
            echo 'Student information data is not Saved';
        }
    }
        public function update_edit_service_by_id($service_id) {
        $select = "SELECT * FROM service WHERE service_id = '$service_id'";
        $result = mysqli_query($this->con, $select);
        if ($result) {
            return $result;
        } else {
            echo 'Problem';
        }
    }

    public function deleteserviceinfo($id_delete) {
        $delete = "DELETE FROM service WHERE service_id='$id_delete'";
        $result = mysqli_query($this->con, $delete);
        if ($result) {
           $message='Student Information is Delete';
            return $message;
        } else {
            echo 'Problem';
        }
    }
        public function selectedinfobyid() {
        $select = "SELECT * FROM service ORDER BY service_id DESC limit 4";
        $result = mysqli_query($this->con, $select);
        if ($result) {
            return $result;
        } else {
            echo 'Problem';
        }
    }
            public function details_service($service_id) {
        $select = "SELECT * FROM service WHERE service_id = '$service_id'";
        $result = mysqli_query($this->con, $select);
        if ($result) {
            return $result;
        } else {
            echo 'Problem';
        }
    }

}
