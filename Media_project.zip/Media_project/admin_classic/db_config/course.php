<?php

class Course {
    private $con;
    public function __construct() {
        $datahost = "localhost";
        $datauser = "root";
        $datapass = "";
        $database = "media_vision_institute";
        $this->con = mysqli_connect($datahost, $datauser, $datapass, $database);
        if (!$this->con) {
            die('Database and Server not Found' . mysqli_error($this->con));
        }
    }

    public function courseinfo($input) {
        $sta = "INSERT INTO courses(course_name, courses_info, courses_outline, courses_duration, courses_fee, courses_class, image) VALUES ('$input[course_name]','$input[course_info]','$input[outline]','$input[duration]','$input[fee]','$input[class]','$input[file]')";
        $result = mysqli_query($this->con, $sta);
        if ($result) {
            ?>
<script type="javascript">
    window.alert("Are You Sure");
</script>
            <?php

        } else {
            echo 'Student information data is not Saved';
        }
    }

    public function selectedinfo() {
        $select = "SELECT * FROM courses";
        $result = mysqli_query($this->con, $select);
        if ($result) {
            return $result;
        } else {
            echo 'Problem';
        }
    }

    public function update_edit_course_by_id($course_id) {
        $select = "SELECT * FROM courses WHERE courses_id = '$course_id'";
        $result = mysqli_query($this->con, $select);
        if ($result) {
            return $result;
        } else {
            echo 'Problem';
        }
    }

    public function updatecourse($data_id) {
        $update = "UPDATE courses SET course_name='$data_id[course_name]',courses_info='$data_id[course_info]',courses_outline='$data_id[outline]',courses_duration='$data_id[duration]',courses_fee='$data_id[fee]',courses_class='$data_id[class]',image='$data_id[file]' WHERE courses_id='$data_id[course_id]'";
        $updatesql = mysqli_query($this->con, $update);
        if ($updatesql) {
  
        } else {
            echo 'Student information data is not Saved';
        }
    }

    public function deletecourseinfo($id_delete) {
        $delete = "DELETE FROM courses WHERE courses_id='$id_delete'";
        $result = mysqli_query($this->con, $delete);
        if ($result) {
           $message='Student Information is Delete';
            return $message;
        } else {
            echo 'Problem';
        }
    }
    
        public function selectedinfoby() {
        $select = "SELECT * FROM courses ORDER BY courses_id ASC limit 8 ";
        $result = mysqli_query($this->con, $select);
        if ($result) {
            return $result;
        } else {
            echo 'Problem';
        }
    }
            public function selectedinfobyed() {
        $select = "SELECT * FROM courses ORDER BY courses_id ASC limit 8 ";
        $result = mysqli_query($this->con, $select);
        if ($result) {
            return $result;
        } else {
            echo 'Problem';
        }
    }


}
