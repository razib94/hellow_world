<?php include 'admin_information/header.php'; 
 include 'admin_information/navigration.php';
 require  'db_config/gallery.php';
$obj_galler_view = new Gallery();
if (isset($_GET['delete'])) {
    $id_delete = $_GET['delete'];
    $deleteinfo = $obj_galler_view->deletegalleryinfo($id_delete);
}
$select = $obj_galler_view->selectedinfo();
 ?> 
<div class="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="#"> Top Bar Offer </a>
            </li>
            <li class="breadcrumb-item active"> Offer Message </li>
        </ol>

<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
              <thead>
                <tr>
                  <th> ID </th>
                  <th> Image Name </th>
                  <th> Image </th>
                  <th> Action </th>
                </tr>
              </thead>
               <?php while($rows = mysqli_fetch_assoc($select)){ ?>
              <tr>
                  <td> <?php echo $rows['gallery_id']; ?></td>
                  <td> <?php echo $rows['name']; ?></td>
                  <td><img src="<?php echo $rows['image']; ?>" alt="gallery" height="50" width="50"/> </td>
                  <td> <a href="edit_gallery.php?id=<?php echo $rows['gallery_id']; ?>" class="btn btn-info"> Edit </a> <a href="?delete=<?php echo $rows['gallery_id']; ?>" class="btn btn-danger"> Delete </a> </td>
              </tr>
               <?php  } ?>
              <tbody>
              </tbody>
            </table>
    <?php include 'admin_information/footer.php'; ?>