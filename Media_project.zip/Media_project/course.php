<?php include 'backFolder/front_header.php'; 

$obj_course = new Course();
$selects = $obj_course->selectedinfoby();
?>
    <div class="bread_area">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <ol class="breadcrumb">
                        <li><a href="#">Home</a></li>
                        <li class="active"> Courses </li>
                    </ol>                    
                </div>
            </div>
        </div>
    </div>
<main class="site-main">
    <section class="services boxes_area">
        <h2 class="section-title">Courses</h2>
        <p class="desc">Praesent faucibus ipsum at sodales blandit</p>
        <div class="container">
            <div class="row">
                 <?php while($rows= mysqli_fetch_assoc($selects)){ ?>
                <div class="col-md-3 col-sm-6 col-xsx-6">
                    <div class="serviceBox">
                        <div class="service-icon">
                            <img src="image/logo/main_logo.png" alt="logo" width="50" height="50"/>
                        </div>
                        <div class="service-content">
                            <h3 class="title"><?php echo $rows['course_name']; ?></h3>
                            <a href="courses.php?id=<?php echo $rows['courses_id']; ?>" class="read-more fa fa-plus" data-toggle="tooltip" title="Read More"></a>
                        </div>
                    </div>
                </div>
                 <?php } ?>
               <!-- <div class="col-md-3 col-sm-6 col-xsx-6">
                    <div class="serviceBox green">
                        <div class="service-icon">
                            <span><i class="fa fa-desktop"></i></span>
                        </div>
                        <div class="service-content">
                            <h3 class="title">Web Development</h3>
                            <a href="WebDevelopment.html" class="read-more fa fa-plus" data-toggle="tooltip" title="Read More"></a>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 col-sm-6 col-xsx-6">
                    <div class="serviceBox orange">
                        <div class="service-icon">
                            <span><i class="fa fa-tablet"></i></span>
                        </div>
                        <div class="service-content">
                            <h3 class="title">Mobile App Devlopment</h3>
                            <a href="MobileAppDevelopment.html" class="read-more fa fa-plus" data-toggle="tooltip" title="Read More"></a>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 col-sm-6 col-xsx-6">
                    <div class="serviceBox blue">
                        <div class="service-icon">
                            <span><i class="fa fa-shopping-cart"></i></span>
                        </div>
                        <div class="service-content">
                            <h3 class="title">E-Commarce</h3>
                            <a href="ECommarce.html" class="read-more fa fa-plus" data-toggle="tooltip" title="Read More"></a>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 col-xsx-6">
                    <div class="serviceBox">
                        <div class="service-icon">
                            <span><i class="fa fa-id-card-o"></i></span>
                        </div>
                        <div class="service-content">
                            <h3 class="title">Web Desinging</h3>
                            <a href="WebDesigning.html" class="read-more fa fa-plus" data-toggle="tooltip" title="Read More"></a>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 col-sm-6 col-xsx-6">
                    <div class="serviceBox green">
                        <div class="service-icon">
                            <span><i class="fa fa-desktop"></i></span>
                        </div>
                        <div class="service-content">
                            <h3 class="title">Web Development</h3>
                            <a href="WebDevelopment.html" class="read-more fa fa-plus" data-toggle="tooltip" title="Read More"></a>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 col-sm-6 col-xsx-6">
                    <div class="serviceBox orange">
                        <div class="service-icon">
                            <span><i class="fa fa-tablet"></i></span>
                        </div>
                        <div class="service-content">
                            <h3 class="title">Mobile App Devlopment</h3>
                            <a href="MobileAppDevelopment.html" class="read-more fa fa-plus" data-toggle="tooltip" title="Read More"></a>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 col-sm-6 col-xsx-6">
                    <div class="serviceBox blue">
                        <div class="service-icon">
                            <span><i class="fa fa-shopping-cart"></i></span>
                        </div>
                        <div class="service-content">
                            <h3 class="title">E-Commarce</h3>
                            <a href="ECommarce.html" class="read-more fa fa-plus" data-toggle="tooltip" title="Read More"></a>
                        </div>
                    </div>
                </div>-->
            </div>
        </div>
    </section>
    <section class="home-area">
        <div class="home_content">
            <div class="container">
                <div class="row">
                    
                    <div class="col-sm-9 home_bottom">
                        <h2 class="sub_title">REFERENCES</h2>
                        <div class="clearfix"></div>
                        <div class="row">
                            <div class="carousel slide" data-ride="carousel" data-type="multi" data-interval="6000" id="myCarousel">
                                <div class="carousel-inner">
                                    <div class="item active">
                                        <div class="col-md-2 col-sm-6 col-xs-12 p10">
                                            <a href="#"><img src="img/l1.jpg" class="img-responsive" alt="Reference"></a>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="col-md-2 col-sm-6 col-xs-12 p10">
                                            <a href="#"><img src="img/l2.jpg" class="img-responsive" alt="Reference"></a>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="col-md-2 col-sm-6 col-xs-12">
                                            <a href="#"><img src="img/l3.jpg" class="img-responsive" alt="Reference"></a>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="col-md-2 col-sm-6 col-xs-12">
                                            <a href="#"><img src="img/l4.jpg" class="img-responsive" alt="Reference"></a>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="col-md-2 col-sm-6 col-xs-12">
                                            <a href="#"><img src="img/l5.jpg" class="img-responsive" alt="Reference"></a>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="col-md-2 col-sm-6 col-xs-12">
                                            <a href="#"><img src="img/l6.jpg" class="img-responsive" alt="Reference"></a>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="col-md-2 col-sm-6 col-xs-12">
                                            <a href="#"><img src="img/l7.jpg" class="img-responsive" alt="Reference"></a>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="col-md-2 col-sm-6 col-xs-12">
                                            <a href="#"><img src="img/l8.jpg" class="img-responsive" alt="Reference"></a>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="col-md-2 col-sm-6 col-xs-12 p10">
                                            <a href="#"><img src="img/l1.jpg" class="img-responsive" alt="Reference"></a>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="col-md-2 col-sm-6 col-xs-12 p10">
                                            <a href="#"><img src="img/l2.jpg" class="img-responsive" alt="Reference"></a>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="col-md-2 col-sm-6 col-xs-12">
                                            <a href="#"><img src="img/l3.jpg" class="img-responsive" alt="Reference"></a>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="col-md-2 col-sm-6 col-xs-12">
                                            <a href="#"><img src="img/l4.jpg" class="img-responsive" alt="Reference"></a>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="col-md-2 col-sm-6 col-xs-12">
                                            <a href="#"><img src="img/l5.jpg" class="img-responsive" alt="Reference"></a>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="col-md-2 col-sm-6 col-xs-12">
                                            <a href="#"><img src="img/l6.jpg" class="img-responsive" alt="Reference"></a>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="col-md-2 col-sm-6 col-xs-12">
                                            <a href="#"><img src="img/l7.jpg" class="img-responsive" alt="Reference"></a>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="col-md-2 col-sm-6 col-xs-12">
                                            <a href="#"><img src="img/l8.jpg" class="img-responsive" alt="Reference"></a>
                                        </div>
                                    </div>                                        
                                </div>
                                <a class="left carousel-control" href="#myCarousel" data-slide="prev"><i class="glyphicon glyphicon-chevron-left"></i></a>
                                <a class="right carousel-control" href="#myCarousel" data-slide="next"><i class="glyphicon glyphicon-chevron-right"></i></a>
                            </div>
                        </div>                            
                    </div>
                    <div class="col-sm-3">
                        <h2 class="sub_title w10">CALL YOU</h2>
                        <div class="clearfix"></div>
                        <div class="login-form-1">
                            <form id="login-form" class="text-left">
                                <div class="login-form-main-message"></div>
                                <div class="main-login-form">
                                    <div class="login-group">
                                        <div class="form-group">
                                            <label for="ad" class="sr-only">Name</label>
                                            <input type="text" class="form-control" id="ad" name="ad" placeholder="Name">
                                        </div>
                                        <div class="form-group">
                                            <label for="tel" class="sr-only">Phone Number</label>
                                            <input type="text" class="form-control" id="tel" name="tel" placeholder="Phone Number">
                                        </div>
                                    </div>
                                    <button type="submit" class="login-button"><i class="fa fa-chevron-right"></i></button>
                                </div>
                            </form>
                        </div>                            
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>

<?php include 'backFolder/front_footer.php'; ?>

