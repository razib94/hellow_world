<?php include 'backFolder/front_header.php'; ?>
<div class="bread_area">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <ol class="breadcrumb">
                    <li><a href="#">Home</a></li>
                    <li class="active"> Contact Page </li>
                </ol>                    
            </div>
        </div>
    </div>
</div>
<main class="site-main page-main">
    <div class="container">
        <div class="row">
            <section class="page col-sm-9">
                <h2 class="page-title"> CONTACT INFORMATION </h2>
                <div class="col-md-10">
                <div class="form-area">  
                    <form role="form">
                        <div class="form-group">
                            <input type="text" class="form-control" id="name" name="name" placeholder="Name" required>
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" id="email" name="email" placeholder="Email" required>
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" id="mobile" name="mobile" placeholder="Mobile Number" required>
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" id="subject" name="subject" placeholder="Subject" required>
                        </div>
                        <div class="form-group">
                            <textarea class="form-control" type="textarea" id="message" placeholder="Message" maxlength="140" rows="7"></textarea>
                            <span class="help-block"><p id="characterLeft" class="help-block ">You have reached the limit</p></span>                    
                        </div>

                        <button type="button" id="submit" name="submit" class="btn btn-primary pull-right">Submit Form</button>
                    </form>
                </div>
                </div>
            </section>
            <aside class="sidebar col-sm-3">
                
                <div class="widget">
                    <h3> <strong style="color: green;"> Head Office </strong></h3>
                    House No: X-25, Razia Sultana Road, Mohammadpur, Dhaka-1207.
                </div>
                <div class="widget">
                    <h3 class="text-success"> Branch Office </h3>
                    House: 4/2, Block-E, Lalmatia, Mohammadpur, Dhaka-1207.
                </div>
            </aside>
        </div>
    </div>
</main>

<?php include 'backFolder/front_footer.php'; ?>
