<?php include 'backFolder/front_header.php'; ?>   
<main class="site-main">
  <div class="bread_area">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <ol class="breadcrumb">
                        <li><a href="#">Home</a></li>
                        <li class="active"> Blog </li>
                        <li class=""> <?php //echo $rows['course_name']; ?> </li>
                    </ol>                    
                </div>
            </div>
        </div>
    </div>
    <main class="site-main category-main">
        <div class="container">
            <div class="row">
                <section class="category-content col-sm-9">
                    <h2 class="category-title">CATEGORY NAME</h2>
                    <ul class="media-list">
                        <li class="media">
                            <div class="media-left">
                                <a href="#" title="Post">
                                    <img class="media-object" src="img/h1.jpeg" alt="Post">
                                </a>
                            </div>
                            <div class="media-body">
                                <h3 class="media-heading"><a href="#" title="Post Title">Post Title</a></h3>
                                <p>Aenean vitae dolor sed purus tempus ullamcorper. Integer urna orci, lacinia ut ornare sit amet, luctus quis est. Ut interdum lorem in mattis lobortis. Maecenas tincidunt justo a lobortis facilisis.</p>
                                <aside class="meta category-meta">
                                    <div class="pull-left">
                                        <div class="arc-comment"><a href="#" title="Comment"><i class="fa fa-comments"></i> 0 Comment</a></div>
                                        <div class="arc-date">10/15/2016</div>
                                    </div>
                                    <div class="pull-right">
                                        <ul class="arc-share">
                                            <li><a href="#" title="Post"><i class="fa fa-facebook"></i></a></li>
                                            <li><a href="#" title="Post"><i class="fa fa-twitter"></i></a></li>
                                            <li><a href="#" title="Post"><i class="fa fa-linkedin"></i></a></li>
                                            <li><a href="#" title="Post"><i class="fa fa-google-plus"></i></a></li>
                                        </ul>
                                    </div>
                                </aside>                                
                            </div>
                        </li>
                        <li class="media">
                            <div class="media-left">
                                <a href="#" title="Post">
                                    <img class="media-object" src="img/h2.jpg" alt="Post">
                                </a>
                            </div>
                            <div class="media-body">
                                <h3 class="media-heading"><a href="#" title="Post Title">Post Title</a></h3>
                                <p>Aenean vitae dolor sed purus tempus ullamcorper. Integer urna orci, lacinia ut ornare sit amet, luctus quis est. Ut interdum lorem in mattis lobortis. Maecenas tincidunt justo a lobortis facilisis.</p>
                                <aside class="meta category-meta">
                                    <div class="pull-left">
                                        <div class="arc-comment"><a href="#" title="Comment"><i class="fa fa-comments"></i> 1 Comment</a></div>
                                        <div class="arc-date">10/15/2016</div>
                                    </div>
                                    <div class="pull-right">
                                        <ul class="arc-share">
                                            <li><a href="#" title="Post"><i class="fa fa-facebook"></i></a></li>
                                            <li><a href="#" title="Post"><i class="fa fa-twitter"></i></a></li>
                                            <li><a href="#" title="Post"><i class="fa fa-linkedin"></i></a></li>
                                            <li><a href="#" title="Post"><i class="fa fa-google-plus"></i></a></li>
                                        </ul>
                                    </div>
                                </aside>                                
                            </div>
                        </li>
                        <li class="media">
                            <div class="media-left">
                                <a href="#" title="Post">
                                    <img class="media-object" src="img/h3.jpeg" alt="Post">
                                </a>
                            </div>
                            <div class="media-body">
                                <h3 class="media-heading"><a href="#" title="Post Title">Post Title</a></h3>
                                <p>Aenean vitae dolor sed purus tempus ullamcorper. Integer urna orci, lacinia ut ornare sit amet, luctus quis est. Ut interdum lorem in mattis lobortis. Maecenas tincidunt justo a lobortis facilisis.</p>
                                <aside class="meta category-meta">
                                    <div class="pull-left">
                                        <div class="arc-comment"><a href="#" title="Comment"><i class="fa fa-comments"></i> 2 Comments</a></div>
                                        <div class="arc-date">10/15/2016</div>
                                    </div>
                                    <div class="pull-right">
                                        <ul class="arc-share">
                                            <li><a href="#" title="Post"><i class="fa fa-facebook"></i></a></li>
                                            <li><a href="#" title="Post"><i class="fa fa-twitter"></i></a></li>
                                            <li><a href="#" title="Post"><i class="fa fa-linkedin"></i></a></li>
                                            <li><a href="#" title="Post"><i class="fa fa-google-plus"></i></a></li>
                                        </ul>
                                    </div>
                                </aside>                                
                            </div>
                        </li>
                        <li class="media">
                            <div class="media-left">
                                <a href="#" title="Post">
                                    <img class="media-object" src="img/h4.jpeg" alt="Post">
                                </a>
                            </div>
                            <div class="media-body">
                                <h3 class="media-heading"><a href="#" title="Post Title">Post Title</a></h3>
                                <p>Aenean vitae dolor sed purus tempus ullamcorper. Integer urna orci, lacinia ut ornare sit amet, luctus quis est. Ut interdum lorem in mattis lobortis. Maecenas tincidunt justo a lobortis facilisis.</p>
                                <aside class="meta category-meta">
                                    <div class="pull-left">
                                        <div class="arc-comment"><a href="#" title="Comment"><i class="fa fa-comments"></i> 2 Comments</a></div>
                                        <div class="arc-date">10/15/2016</div>
                                    </div>
                                    <div class="pull-right">
                                        <ul class="arc-share">
                                            <li><a href="#" title="Post"><i class="fa fa-facebook"></i></a></li>
                                            <li><a href="#" title="Post"><i class="fa fa-twitter"></i></a></li>
                                            <li><a href="#" title="Post"><i class="fa fa-linkedin"></i></a></li>
                                            <li><a href="#" title="Post"><i class="fa fa-google-plus"></i></a></li>
                                        </ul>
                                    </div>
                                </aside>                                
                            </div>
                        </li>
                        <li class="media">
                            <div class="media-left">
                                <a href="#" title="Post">
                                    <img class="media-object" src="img/h1.jpeg" alt="Post">
                                </a>
                            </div>
                            <div class="media-body">
                                <h3 class="media-heading"><a href="#" title="Post Title">Post Title</a></h3>
                                <p>Aenean vitae dolor sed purus tempus ullamcorper. Integer urna orci, lacinia ut ornare sit amet, luctus quis est. Ut interdum lorem in mattis lobortis. Maecenas tincidunt justo a lobortis facilisis.</p>
                                <aside class="meta category-meta">
                                    <div class="pull-left">
                                        <div class="arc-comment"><a href="#" title="Comment"><i class="fa fa-comments"></i> 12 Comments</a></div>
                                        <div class="arc-date">10/15/2016</div>
                                    </div>
                                    <div class="pull-right">
                                        <ul class="arc-share">
                                            <li><a href="#" title="Post"><i class="fa fa-facebook"></i></a></li>
                                            <li><a href="#" title="Post"><i class="fa fa-twitter"></i></a></li>
                                            <li><a href="#" title="Post"><i class="fa fa-linkedin"></i></a></li>
                                            <li><a href="#" title="Post"><i class="fa fa-google-plus"></i></a></li>
                                        </ul>
                                    </div>
                                </aside>                                
                            </div>
                        </li>
                        <li class="media">
                            <div class="media-left">
                                <a href="#" title="Post">
                                    <img class="media-object" src="img/h2.jpg" alt="Post">
                                </a>
                            </div>
                            <div class="media-body">
                                <h3 class="media-heading"><a href="#" title="Post Title">Post Title</a></h3>
                                <p>Aenean vitae dolor sed purus tempus ullamcorper. Integer urna orci, lacinia ut ornare sit amet, luctus quis est. Ut interdum lorem in mattis lobortis. Maecenas tincidunt justo a lobortis facilisis.</p>
                                <aside class="meta category-meta">
                                    <div class="pull-left">
                                        <div class="arc-comment"><a href="#" title="Comment"><i class="fa fa-comments"></i> 2 Comments</a></div>
                                        <div class="arc-date">10/15/2016</div>
                                    </div>
                                    <div class="pull-right">
                                        <ul class="arc-share">
                                            <li><a href="#" title="Post"><i class="fa fa-facebook"></i></a></li>
                                            <li><a href="#" title="Post"><i class="fa fa-twitter"></i></a></li>
                                            <li><a href="#" title="Post"><i class="fa fa-linkedin"></i></a></li>
                                            <li><a href="#" title="Post"><i class="fa fa-google-plus"></i></a></li>
                                        </ul>
                                    </div>
                                </aside>                                
                            </div>
                        </li>
                        <li class="media">
                            <div class="media-left">
                                <a href="#" title="Post">
                                    <img class="media-object" src="img/h3.jpeg" alt="Post">
                                </a>
                            </div>
                            <div class="media-body">
                                <h3 class="media-heading"><a href="#" title="Post Title">Post Title</a></h3>
                                <p>Aenean vitae dolor sed purus tempus ullamcorper. Integer urna orci, lacinia ut ornare sit amet, luctus quis est. Ut interdum lorem in mattis lobortis. Maecenas tincidunt justo a lobortis facilisis.</p>
                                <aside class="meta category-meta">
                                    <div class="pull-left">
                                        <div class="arc-comment"><a href="#" title="Comment"><i class="fa fa-comments"></i> 3 Comments</a></div>
                                        <div class="arc-date">10/15/2016</div>
                                    </div>
                                    <div class="pull-right">
                                        <ul class="arc-share">
                                            <li><a href="#" title="Post"><i class="fa fa-facebook"></i></a></li>
                                            <li><a href="#" title="Post"><i class="fa fa-twitter"></i></a></li>
                                            <li><a href="#" title="Post"><i class="fa fa-linkedin"></i></a></li>
                                            <li><a href="#" title="Post"><i class="fa fa-google-plus"></i></a></li>
                                        </ul>
                                    </div>
                                </aside>                                
                            </div>
                        </li>
                        <li class="media">
                            <div class="media-left">
                                <a href="#" title="Post">
                                    <img class="media-object" src="img/h4.jpeg" alt="Post">
                                </a>
                            </div>
                            <div class="media-body">
                                <h3 class="media-heading"><a href="#" title="Post Title">Post Title</a></h3>
                                <p>Aenean vitae dolor sed purus tempus ullamcorper. Integer urna orci, lacinia ut ornare sit amet, luctus quis est. Ut interdum lorem in mattis lobortis. Maecenas tincidunt justo a lobortis facilisis.</p>
                                <aside class="meta category-meta">
                                    <div class="pull-left">
                                        <div class="arc-comment"><a href="#" title="Comment"><i class="fa fa-comments"></i> 8 Comments</a></div>
                                        <div class="arc-date">10/15/2016</div>
                                    </div>
                                    <div class="pull-right">
                                        <ul class="arc-share">
                                            <li><a href="#" title="Post"><i class="fa fa-facebook"></i></a></li>
                                            <li><a href="#" title="Post"><i class="fa fa-twitter"></i></a></li>
                                            <li><a href="#" title="Post"><i class="fa fa-linkedin"></i></a></li>
                                            <li><a href="#" title="Post"><i class="fa fa-google-plus"></i></a></li>
                                        </ul>
                                    </div>
                                </aside>                                
                            </div>
                        </li>                        
                    </ul>                    
                </section>
                <aside class="sidebar col-sm-3">
                    <div class="widget">
                        <h4>SERVICES</h4>
                        <ul>
                            <li class="current"><a href="#" title="">Service Title One</a></li>
                            <li><a href="#" title="">Service Title Two</a></li>
                            <li><a href="#" title="">Service Title Three</a></li>
                            <li><a href="#" title="">Service Title Four</a></li>
                        </ul>
                    </div>
                </aside>
            </div>
        </div>
        <section class="home-area">
        <div class="home_content">
            <div class="container">
                <div class="row">
                    <div class="col-sm-9 home_bottom">
                        <h2 class="sub_title">REFERENCES</h2>
                        <div class="clearfix"></div>
                        <div class="row">
                            <div class="carousel slide" data-ride="carousel" data-type="multi" data-interval="6000" id="myCarousel">
                                <div class="carousel-inner">
                                    <div class="item active">
                                        <div class="col-md-2 col-sm-6 col-xs-12 p10">
                                            <a href="#"><img src="img/l1.jpg" class="img-responsive" alt="Reference"></a>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="col-md-2 col-sm-6 col-xs-12 p10">
                                            <a href="#"><img src="img/l2.jpg" class="img-responsive" alt="Reference"></a>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="col-md-2 col-sm-6 col-xs-12">
                                            <a href="#"><img src="img/l3.jpg" class="img-responsive" alt="Reference"></a>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="col-md-2 col-sm-6 col-xs-12">
                                            <a href="#"><img src="img/l4.jpg" class="img-responsive" alt="Reference"></a>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="col-md-2 col-sm-6 col-xs-12">
                                            <a href="#"><img src="img/l5.jpg" class="img-responsive" alt="Reference"></a>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="col-md-2 col-sm-6 col-xs-12">
                                            <a href="#"><img src="img/l6.jpg" class="img-responsive" alt="Reference"></a>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="col-md-2 col-sm-6 col-xs-12">
                                            <a href="#"><img src="img/l7.jpg" class="img-responsive" alt="Reference"></a>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="col-md-2 col-sm-6 col-xs-12">
                                            <a href="#"><img src="img/l8.jpg" class="img-responsive" alt="Reference"></a>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="col-md-2 col-sm-6 col-xs-12 p10">
                                            <a href="#"><img src="img/l1.jpg" class="img-responsive" alt="Reference"></a>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="col-md-2 col-sm-6 col-xs-12 p10">
                                            <a href="#"><img src="img/l2.jpg" class="img-responsive" alt="Reference"></a>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="col-md-2 col-sm-6 col-xs-12">
                                            <a href="#"><img src="img/l3.jpg" class="img-responsive" alt="Reference"></a>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="col-md-2 col-sm-6 col-xs-12">
                                            <a href="#"><img src="img/l4.jpg" class="img-responsive" alt="Reference"></a>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="col-md-2 col-sm-6 col-xs-12">
                                            <a href="#"><img src="img/l5.jpg" class="img-responsive" alt="Reference"></a>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="col-md-2 col-sm-6 col-xs-12">
                                            <a href="#"><img src="img/l6.jpg" class="img-responsive" alt="Reference"></a>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="col-md-2 col-sm-6 col-xs-12">
                                            <a href="#"><img src="img/l7.jpg" class="img-responsive" alt="Reference"></a>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="col-md-2 col-sm-6 col-xs-12">
                                            <a href="#"><img src="img/l8.jpg" class="img-responsive" alt="Reference"></a>
                                        </div>
                                    </div>                                        
                                </div>
                                <a class="left carousel-control" href="#myCarousel" data-slide="prev"><i class="glyphicon glyphicon-chevron-left"></i></a>
                                <a class="right carousel-control" href="#myCarousel" data-slide="next"><i class="glyphicon glyphicon-chevron-right"></i></a>
                            </div>
                        </div>                            
                    </div>
                    <div class="col-sm-3">
                        <h2 class="sub_title w10">CALL YOU</h2>
                        <div class="clearfix"></div>
                        <div class="login-form-1">
                            <form id="login-form" class="text-left">
                                <div class="login-form-main-message"></div>
                                <div class="main-login-form">
                                    <div class="login-group">
                                        <div class="form-group">
                                            <label for="ad" class="sr-only">Name</label>
                                            <input type="text" class="form-control" id="ad" name="ad" placeholder="Name">
                                        </div>
                                        <div class="form-group">
                                            <label for="tel" class="sr-only">Phone Number</label>
                                            <input type="text" class="form-control" id="tel" name="tel" placeholder="Phone Number">
                                        </div>
                                    </div>
                                    <button type="submit" class="login-button"><i class="fa fa-chevron-right"></i></button>
                                </div>
                            </form>
                        </div>                            
                    </div>
                </div>
            </div>
        </div>
    </section>
    </main>
   <?php include 'backFolder/front_footer.php'; ?>