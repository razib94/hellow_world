<?php
require 'admin_classic/db_config/top.php';
require 'admin_classic/db_config/banner.php';
require  'admin_classic/db_config/course.php';
require  'admin_classic/db_config/gallery.php';
require  'admin_classic/db_config/blog.php';
require  'admin_classic/db_config/service.php';
$obj_courses = new Course();
$selects = $obj_courses->selectedinfoby();
$top_obj = new Top();
$data_select = $top_obj->selectedinfo();
$object_banner = new Banner();
$select = $object_banner->selectedinfo();
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="icon" href="image/logo/main_logo.png" type="image/png" sizes="16x16">
        <title>  Media Vision Institute </title>

        <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600&amp;subset=latin-ext" rel="stylesheet">

        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/font-awesome.min.css" rel="stylesheet">
        <link href="style.css" rel="stylesheet">
        <link href="css/styleTwo.css" rel="stylesheet"/>
    </head>

    <body>
        <header class="site-header">
            <div class="top">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-2">
                            <p> mediavision.bd@gmail.com </p>
                        </div>
                        <div class="col-sm-7">
                            
                            <?php $rows = mysqli_fetch_assoc($data_select) ?>
                            <marquee> <p> <?php echo $rows['offer_message']; ?> </p> </marquee>
                            <?php ?>
                        </div>
                        <div class="col-sm-3">
                            <ul class="list-inline pull-right">
                                <li><a target="_blank" href="https://www.facebook.com/mvibd"><i class="fa fa-facebook"></i></a></li>
                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                <li><a href="#"><i class="fa fa-envelope-o"></i></a></li>
                                <li><a href="tel:+902222222222"><i class="fa fa-phone"></i> +880 1917 30 49 59</a></li>
                            </ul>                        
                        </div>
                    </div>
                </div>
            </div>
            <div class="">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-3">
                            <a href="index.php" class="navbar-brand logo_size">
                                <img src="image/logo/main_logo.png" alt="logo" class="img-responsive">
                            </a>
                        </div>
                        <div class="col-sm-6">
                            <div class="head-search">
                                <div class="col-sm-8 col-sm-offset-2">
                                <div class="form-group">
                                    <div class="input-group">
                                        <input class="form-control" type="text" name="search" placeholder="Search" required />
                                        <span class="input-group-btn">
                                            <button class="btn btn-success" type="submit"><span class="glyphicon glyphicon-search" aria-hidden="true"><span style="margin-left:10px;">Search</span></button>
                                        </span>
                                        </span>
                                    </div>
                                </div>
                            </div>
                            </div>
                        </div>
                        <div class="col-sm-6">

                        </div>
                    </div>
                </div>
            </div>
            <nav class="navbar navbar-default">
                <div class="container">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-navbar-collapse">
                        <span class="sr-only">Toggle Navigation</span>
                        <i class="fa fa-bars"></i>
                    </button>
                    <div class="collapse navbar-collapse" id="bs-navbar-collapse">
                        <ul class="nav navbar-nav main-navbar-nav">
                            <li class="active"><a href="index.php" title="">HOME</a></li>
                            <li class="dropdown">
                                <a href="courses.php" title="" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">TRAINING COURSES <span class="caret"></span></a>
                                <ul class="dropdown-menu">
                                    <?php while($rows= mysqli_fetch_assoc($selects)){ ?>
                                    <li><a href="courses.php?id=<?php echo $rows['courses_id']; ?>" title=""><?php echo $rows['course_name']; ?></a></li>
                                    <?php } ?>
                                </ul>
                            </li>
                            <li><a href="about.php" title="">ABOUT US </a></li>
                            <li><a href="course.php" title=""> COURSES </a></li>
                            <li><a href="service.php" title="">SERVICE</a></li>
                             <li><a href="blog.php" title="">Blog</a></li>
                            <li><a href="gallery.php" title="">GALLERY</a></li>
                            <li><a href="contact.php" title=""> CONTACT </a></li>
                        </ul>                           
                    </div>
                </div>
            </nav>        
        </header>
        