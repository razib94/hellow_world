<?php include 'backFolder/front_header.php'; 
$objec_service = new Service();
$select = $objec_service->selectedinfobyid();
?>   
<style>
    .services-sectioned {padding-top:60px; padding-bottom:60px;background:#e2e2e2;}
.service-box h3 {
    color: #59626b;
    font-size: 20px;
    font-weight: normal;
    text-transform: capitalize;
    line-height: 36px;
    letter-spacing:1px;
    margin: 0;
}
.service-contented p {margin-top:5px;margin-bottom: 20px;}
.service-icon{width: 50px;
    height: 50px;
    border: 1px solid #e4e4e4;
    text-align: center;
    line-height: 50px;
    font-size: 30px;
    float:left;
    display: table;
    color:red;
    transform: rotate(-45deg);}
.service-contented{ margin-top: 40px; margin-left:120px;}

    
</style>
<main class="site-main">
    <div class="bread_area">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <ol class="breadcrumb">
                        <li><a href="#">Home</a></li>
                        <li class="active"> Service </li>
                        <li class=""> <?php //echo $rows['course_name'];  ?> </li>
                    </ol>                    
                </div>
            </div>
        </div>
    </div>
    <main class="site-main category-main">
        <div class="services-sectioned">
            <div class="container">
                <div class="row">
                    <div class="col-md-8 col-sm-12">
                        <div class="row">
                            <?php while ($row = mysqli_fetch_assoc($select)){ ?>
                            <a href="service_details.php?id=<?php echo $row['service_id'] ; ?>">
                            <div class="col-md-6 col-sm-6">
                                <div class="service-box">
                                    <div class="service-icon ">
                                        <i class="fa fa-facebook-square fa-3x social"></i>
                                    </div>
                                    <div class="service-contented">
                                        <h3><?php echo $row['service_name']; ?></h3>
                                        <p><?php echo $row['service_info']; ?></p>
                                    </div>
                                </div>

                            </div>
                                 </a>
                            <?php } ?>
                           
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-12">
                        <img src="http://demo.megrithemes.com/azona-large-preview/azona/assets/img/purple-imack.png" class="img-responsive" alt="">
                    </div>
                </div>
            </div>
        </div>
        <section class="home-area">
            <div class="home_content">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-9 home_bottom">
                            <h2 class="sub_title">REFERENCES</h2>
                            <div class="clearfix"></div>
                            <div class="row">
                                <div class="carousel slide" data-ride="carousel" data-type="multi" data-interval="6000" id="myCarousel">
                                    <div class="carousel-inner">
                                        <div class="item active">
                                            <div class="col-md-2 col-sm-6 col-xs-12 p10">
                                                <a href="#"><img src="img/l1.jpg" class="img-responsive" alt="Reference"></a>
                                            </div>
                                        </div>
                                        <div class="item">
                                            <div class="col-md-2 col-sm-6 col-xs-12 p10">
                                                <a href="#"><img src="img/l2.jpg" class="img-responsive" alt="Reference"></a>
                                            </div>
                                        </div>
                                        <div class="item">
                                            <div class="col-md-2 col-sm-6 col-xs-12">
                                                <a href="#"><img src="img/l3.jpg" class="img-responsive" alt="Reference"></a>
                                            </div>
                                        </div>
                                        <div class="item">
                                            <div class="col-md-2 col-sm-6 col-xs-12">
                                                <a href="#"><img src="img/l4.jpg" class="img-responsive" alt="Reference"></a>
                                            </div>
                                        </div>
                                        <div class="item">
                                            <div class="col-md-2 col-sm-6 col-xs-12">
                                                <a href="#"><img src="img/l5.jpg" class="img-responsive" alt="Reference"></a>
                                            </div>
                                        </div>
                                        <div class="item">
                                            <div class="col-md-2 col-sm-6 col-xs-12">
                                                <a href="#"><img src="img/l6.jpg" class="img-responsive" alt="Reference"></a>
                                            </div>
                                        </div>
                                        <div class="item">
                                            <div class="col-md-2 col-sm-6 col-xs-12">
                                                <a href="#"><img src="img/l7.jpg" class="img-responsive" alt="Reference"></a>
                                            </div>
                                        </div>
                                        <div class="item">
                                            <div class="col-md-2 col-sm-6 col-xs-12">
                                                <a href="#"><img src="img/l8.jpg" class="img-responsive" alt="Reference"></a>
                                            </div>
                                        </div>
                                        <div class="item">
                                            <div class="col-md-2 col-sm-6 col-xs-12 p10">
                                                <a href="#"><img src="img/l1.jpg" class="img-responsive" alt="Reference"></a>
                                            </div>
                                        </div>
                                        <div class="item">
                                            <div class="col-md-2 col-sm-6 col-xs-12 p10">
                                                <a href="#"><img src="img/l2.jpg" class="img-responsive" alt="Reference"></a>
                                            </div>
                                        </div>
                                        <div class="item">
                                            <div class="col-md-2 col-sm-6 col-xs-12">
                                                <a href="#"><img src="img/l3.jpg" class="img-responsive" alt="Reference"></a>
                                            </div>
                                        </div>
                                        <div class="item">
                                            <div class="col-md-2 col-sm-6 col-xs-12">
                                                <a href="#"><img src="img/l4.jpg" class="img-responsive" alt="Reference"></a>
                                            </div>
                                        </div>
                                        <div class="item">
                                            <div class="col-md-2 col-sm-6 col-xs-12">
                                                <a href="#"><img src="img/l5.jpg" class="img-responsive" alt="Reference"></a>
                                            </div>
                                        </div>
                                        <div class="item">
                                            <div class="col-md-2 col-sm-6 col-xs-12">
                                                <a href="#"><img src="img/l6.jpg" class="img-responsive" alt="Reference"></a>
                                            </div>
                                        </div>
                                        <div class="item">
                                            <div class="col-md-2 col-sm-6 col-xs-12">
                                                <a href="#"><img src="img/l7.jpg" class="img-responsive" alt="Reference"></a>
                                            </div>
                                        </div>
                                        <div class="item">
                                            <div class="col-md-2 col-sm-6 col-xs-12">
                                                <a href="#"><img src="img/l8.jpg" class="img-responsive" alt="Reference"></a>
                                            </div>
                                        </div>                                        
                                    </div>
                                    <a class="left carousel-control" href="#myCarousel" data-slide="prev"><i class="glyphicon glyphicon-chevron-left"></i></a>
                                    <a class="right carousel-control" href="#myCarousel" data-slide="next"><i class="glyphicon glyphicon-chevron-right"></i></a>
                                </div>
                            </div>                            
                        </div>
                        <div class="col-sm-3">
                            <h2 class="sub_title w10">CALL YOU</h2>
                            <div class="clearfix"></div>
                            <div class="login-form-1">
                                <form id="login-form" class="text-left">
                                    <div class="login-form-main-message"></div>
                                    <div class="main-login-form">
                                        <div class="login-group">
                                            <div class="form-group">
                                                <label for="ad" class="sr-only">Name</label>
                                                <input type="text" class="form-control" id="ad" name="ad" placeholder="Name">
                                            </div>
                                            <div class="form-group">
                                                <label for="tel" class="sr-only">Phone Number</label>
                                                <input type="text" class="form-control" id="tel" name="tel" placeholder="Phone Number">
                                            </div>
                                        </div>
                                        <button type="submit" class="login-button"><i class="fa fa-chevron-right"></i></button>
                                    </div>
                                </form>
                            </div>                            
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
    <?php include 'backFolder/front_footer.php'; ?>