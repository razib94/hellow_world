<?php include 'backFolder/front_header.php'; ?>
<div class="bread_area">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <ol class="breadcrumb">
                    <li><a href="#">Home</a></li>
                    <li class="active"> About Information </li>
                </ol>                    
            </div>
        </div>
    </div>
</div>
<main class="site-main page-main">
    <div class="container">
        <div class="row">
            <section class="page col-sm-9">
                <h2 class="page-title"> ABOUT INFORMATION </h2>
                <div class="entry">
                    <h4> MISSION </h4>
                    <p> Helping people, especially youth, to achieve technical skill and through this go ahead in life.<br/>
                        কারিগরি দক্ষতা অর্জনে মানুষকে সহায়তা করে জীবনে এগিয়ে দেয়া।
                    </p>
                    <h4> ABOUT </h4>
                    <p>About
                        Bangladesh Technical Board approved Computer Training Institute and IT Solution.</p>
                    <h4> PRODUCTS </h4>
                    <p>
                        Computer training, Website design and Development, Logo, Banner, Poster etc design, Online Promotion.</p>

                    <p>Curabitur euismod lobortis sapien. Maecenas magna ligula, vulputate in nulla ac, tincidunt suscipit erat. Sed ac tempor nisi. Suspendisse laoreet, odio et consequat varius, sem urna convallis leo, egestas malesuada elit erat id tellus. Suspendisse scelerisque in felis at pretium. Maecenas dictum quam posuere ex hendrerit tempus. Donec vehicula quis erat quis sollicitudin. Vestibulum ultrices vitae arcu quis dignissim. Donec sagittis tincidunt arcu id pellentesque. Nullam eu risus tristique, mattis arcu laoreet, sagittis purus. Nulla facilisi. Nam ac justo quis elit pharetra scelerisque. Curabitur et dapibus ex. In quis pretium turpis. Aliquam tincidunt quam interdum, faucibus odio a, porttitor dui.</p>

                    <p>Aenean non dapibus ante, sed dictum enim. Maecenas elementum auctor imperdiet. Nam eu mi placerat, dignissim libero condimentum, ornare est. Nunc euismod viverra sapien quis porttitor. Fusce eleifend quam quis nibh dictum scelerisque in vel lacus. Duis ac risus quis eros pretium lobortis. In malesuada est est.</p>                        
                </div>
            </section>
            <aside class="sidebar col-sm-3">
                <div class="widget">
                    <h4>SERVICES</h4>
                    <ul>
                        <li class="current"><a href="#" title="">Service Title One</a></li>
                        <li><a href="#" title="">Service Title Two</a></li>
                        <li><a href="#" title="">Service Title Three</a></li>
                        <li><a href="#" title="">Service Title Four</a></li>
                    </ul>
                </div>
            </aside>
        </div>
    </div>
    <section class="home-area">
        <div class="home_content">
            <div class="container">
                <div class="row">
                    <div class="col-sm-9 home_bottom">
                        <h2 class="sub_title">REFERENCES</h2>
                        <div class="clearfix"></div>
                        <div class="row">
                            <div class="carousel slide" data-ride="carousel" data-type="multi" data-interval="6000" id="myCarousel">
                                <div class="carousel-inner">
                                    <div class="item active">
                                        <div class="col-md-2 col-sm-6 col-xs-12 p10">
                                            <a href="#"><img src="img/l1.jpg" class="img-responsive" alt="Reference"></a>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="col-md-2 col-sm-6 col-xs-12 p10">
                                            <a href="#"><img src="img/l2.jpg" class="img-responsive" alt="Reference"></a>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="col-md-2 col-sm-6 col-xs-12">
                                            <a href="#"><img src="img/l3.jpg" class="img-responsive" alt="Reference"></a>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="col-md-2 col-sm-6 col-xs-12">
                                            <a href="#"><img src="img/l4.jpg" class="img-responsive" alt="Reference"></a>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="col-md-2 col-sm-6 col-xs-12">
                                            <a href="#"><img src="img/l5.jpg" class="img-responsive" alt="Reference"></a>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="col-md-2 col-sm-6 col-xs-12">
                                            <a href="#"><img src="img/l6.jpg" class="img-responsive" alt="Reference"></a>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="col-md-2 col-sm-6 col-xs-12">
                                            <a href="#"><img src="img/l7.jpg" class="img-responsive" alt="Reference"></a>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="col-md-2 col-sm-6 col-xs-12">
                                            <a href="#"><img src="img/l8.jpg" class="img-responsive" alt="Reference"></a>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="col-md-2 col-sm-6 col-xs-12 p10">
                                            <a href="#"><img src="img/l1.jpg" class="img-responsive" alt="Reference"></a>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="col-md-2 col-sm-6 col-xs-12 p10">
                                            <a href="#"><img src="img/l2.jpg" class="img-responsive" alt="Reference"></a>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="col-md-2 col-sm-6 col-xs-12">
                                            <a href="#"><img src="img/l3.jpg" class="img-responsive" alt="Reference"></a>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="col-md-2 col-sm-6 col-xs-12">
                                            <a href="#"><img src="img/l4.jpg" class="img-responsive" alt="Reference"></a>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="col-md-2 col-sm-6 col-xs-12">
                                            <a href="#"><img src="img/l5.jpg" class="img-responsive" alt="Reference"></a>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="col-md-2 col-sm-6 col-xs-12">
                                            <a href="#"><img src="img/l6.jpg" class="img-responsive" alt="Reference"></a>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="col-md-2 col-sm-6 col-xs-12">
                                            <a href="#"><img src="img/l7.jpg" class="img-responsive" alt="Reference"></a>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="col-md-2 col-sm-6 col-xs-12">
                                            <a href="#"><img src="img/l8.jpg" class="img-responsive" alt="Reference"></a>
                                        </div>
                                    </div>                                        
                                </div>
                                <a class="left carousel-control" href="#myCarousel" data-slide="prev"><i class="glyphicon glyphicon-chevron-left"></i></a>
                                <a class="right carousel-control" href="#myCarousel" data-slide="next"><i class="glyphicon glyphicon-chevron-right"></i></a>
                            </div>
                        </div>                            
                    </div>
                    <div class="col-sm-3">
                        <h2 class="sub_title w10">CALL YOU</h2>
                        <div class="clearfix"></div>
                        <div class="login-form-1">
                            <form id="login-form" class="text-left">
                                <div class="login-form-main-message"></div>
                                <div class="main-login-form">
                                    <div class="login-group">
                                        <div class="form-group">
                                            <label for="ad" class="sr-only">Name</label>
                                            <input type="text" class="form-control" id="ad" name="ad" placeholder="Name">
                                        </div>
                                        <div class="form-group">
                                            <label for="tel" class="sr-only">Phone Number</label>
                                            <input type="text" class="form-control" id="tel" name="tel" placeholder="Phone Number">
                                        </div>
                                    </div>
                                    <button type="submit" class="login-button"><i class="fa fa-chevron-right"></i></button>
                                </div>
                            </form>
                        </div>                            
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>
<?php include 'backFolder/front_footer.php'; ?>