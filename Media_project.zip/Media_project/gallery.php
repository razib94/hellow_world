
<?php
include 'backFolder/front_header.php';
$obj_galler_view = new Gallery();
$select = $obj_galler_view->selectedinfoby();
?>
<style>

    .container_galary {
        display: flex;
        flex-wrap: wrap;
        flex-direction: row;
        justify-content: center;
        padding: 0 30px;
    }
    .container_galary .thumbex {
        margin: 10px 20px 30px;
        width: 100%;
        min-width: 250px;
        max-width: 435px;
        height: 300px;
        -webkit-flex: 1;
        -ms-flex: 1;
        flex: 1;
        overflow: hidden;
        outline: 2px solid white;
        outline-offset: -15px;
        background-color: blue;
        box-shadow: 5px 10px 40px 5px rgba(0, 0, 0, 0.5);
    }
    .container_galary .thumbex .thumbnail {
        overflow: hidden;
        min-width: 250px;
        height: 300px;
        position: relative;
        opacity: 0.88;
        backface-visibility: hidden;
        transition: all 0.4s ease-out;
    }
    .container_galary .thumbex .thumbnail img {
        position: absolute;
        z-index: 1;
        left: 50%;
        top: 50%;
        height: 115%;
        width: auto;
        transform: translate(-50%, -50%);
        backface-visibility: hidden;
    }
    .container_galary .thumbex .thumbnail span {
        position: absolute;
        z-index: 2;
        top: calc(150px - 20px);
        left: 0;
        right: 0;
        background: rgba(0, 0, 0, 0.7);
        padding: 10px 50px;
        margin: 0 45px;
        text-align: center;
        font-size: 24px;
        color: white;
        font-weight: 300;
        font-family: "Raleway", sans-serif;
        letter-spacing: 0.2px;
        transition: all 0.3s ease-out;
    }
    .container_galary .thumbex .thumbnail:hover {
        backface-visibility: hidden;
        transform: scale(1.15, 1.15);
        opacity: 1;
    }
    .container_galary .thumbex .thumbnail:hover span {
        opacity: 0;
    }
</style>
<div class="bread_area">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <ol class="breadcrumb">
                    <li><a href="#">Home</a></li>
                    <li class="active"> GALLERY </li>
                </ol>                    
            </div>
        </div>
    </div>
</div>
<main class="site-main"> 
    <section class="services boxes_area">
        <h2 class="section-title">Gallery</h2>
        <p class="desc">Praesent faucibus ipsum at sodales blandit</p>

        <div class="container_galary">
            <div class="row">
                <?php while ($rows = mysqli_fetch_assoc($select)){?>
                <div class="col-md-4 col-xs-6">
                    <div class="thumbex">    
                        <div class="thumbnail"><a href="#"><img src="admin_classic/<?php echo $rows['image']; ?>"/><span>Mountains</span></a></div>
                    </div>

                </div>
                <?php } ?>
                <div class="col-md-4 col-xs-6">
                    <div class="thumbex">
                        <div class="thumbnail"><a href="#"> <img src="admin_classic/images/images (13).jpg"/><span>Beaches</span></a></div>
                    </div>

                </div>
                <div class="col-md-4 col-xs-6">
                    <div class="thumbex">
                        <div class="thumbnail"><a href="#"> <img src="admin_classic/images/images (25).jpg"/><span>Beaches</span></a></div>
                    </div>

                </div>
                <div class="col-md-4 col-xs-6">
                    <div class="thumbex">
                        <div class="thumbnail"><a href="#"> <img src="http://www.lifewallpapers.net/data/out/36/3798243-beach-paradise-wallpaper.jpg"/><span>Beaches</span></a></div>
                    </div>

                </div>
                <div class="col-md-4 col-xs-6">
                    <div class="thumbex">
                        <div class="thumbnail"><a href="#"> <img src="http://www.lifewallpapers.net/data/out/36/3798243-beach-paradise-wallpaper.jpg"/><span>Beaches</span></a></div>
                    </div>

                </div>
                <div class="col-md-4 col-xs-6">
                    <div class="thumbex">
                        <div class="thumbnail"><a href="#"> <img src="http://www.lifewallpapers.net/data/out/36/3798243-beach-paradise-wallpaper.jpg"/><span>Beaches</span></a></div>
                    </div>

                </div>
            </div>
        </div>
    </section>
    <section class="home-area">
        <div class="home_content">
            <div class="container">
                <div class="row">
                    <div class="col-sm-9 home_bottom">
                        <h2 class="sub_title">REFERENCES</h2>
                        <div class="clearfix"></div>
                        <div class="row">
                            <div class="carousel slide" data-ride="carousel" data-type="multi" data-interval="6000" id="myCarousel">
                                <div class="carousel-inner">
                                    <div class="item active">
                                        <div class="col-md-2 col-sm-6 col-xs-12 p10">
                                            <a href="#"><img src="img/l1.jpg" class="img-responsive" alt="Reference"></a>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="col-md-2 col-sm-6 col-xs-12 p10">
                                            <a href="#"><img src="img/l2.jpg" class="img-responsive" alt="Reference"></a>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="col-md-2 col-sm-6 col-xs-12">
                                            <a href="#"><img src="img/l3.jpg" class="img-responsive" alt="Reference"></a>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="col-md-2 col-sm-6 col-xs-12">
                                            <a href="#"><img src="img/l4.jpg" class="img-responsive" alt="Reference"></a>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="col-md-2 col-sm-6 col-xs-12">
                                            <a href="#"><img src="img/l5.jpg" class="img-responsive" alt="Reference"></a>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="col-md-2 col-sm-6 col-xs-12">
                                            <a href="#"><img src="img/l6.jpg" class="img-responsive" alt="Reference"></a>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="col-md-2 col-sm-6 col-xs-12">
                                            <a href="#"><img src="img/l7.jpg" class="img-responsive" alt="Reference"></a>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="col-md-2 col-sm-6 col-xs-12">
                                            <a href="#"><img src="img/l8.jpg" class="img-responsive" alt="Reference"></a>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="col-md-2 col-sm-6 col-xs-12 p10">
                                            <a href="#"><img src="img/l1.jpg" class="img-responsive" alt="Reference"></a>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="col-md-2 col-sm-6 col-xs-12 p10">
                                            <a href="#"><img src="img/l2.jpg" class="img-responsive" alt="Reference"></a>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="col-md-2 col-sm-6 col-xs-12">
                                            <a href="#"><img src="img/l3.jpg" class="img-responsive" alt="Reference"></a>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="col-md-2 col-sm-6 col-xs-12">
                                            <a href="#"><img src="img/l4.jpg" class="img-responsive" alt="Reference"></a>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="col-md-2 col-sm-6 col-xs-12">
                                            <a href="#"><img src="img/l5.jpg" class="img-responsive" alt="Reference"></a>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="col-md-2 col-sm-6 col-xs-12">
                                            <a href="#"><img src="img/l6.jpg" class="img-responsive" alt="Reference"></a>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="col-md-2 col-sm-6 col-xs-12">
                                            <a href="#"><img src="img/l7.jpg" class="img-responsive" alt="Reference"></a>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="col-md-2 col-sm-6 col-xs-12">
                                            <a href="#"><img src="img/l8.jpg" class="img-responsive" alt="Reference"></a>
                                        </div>
                                    </div>                                        
                                </div>
                                <a class="left carousel-control" href="#myCarousel" data-slide="prev"><i class="glyphicon glyphicon-chevron-left"></i></a>
                                <a class="right carousel-control" href="#myCarousel" data-slide="next"><i class="glyphicon glyphicon-chevron-right"></i></a>
                            </div>
                        </div>                            
                    </div>
                    <div class="col-sm-3">
                        <h2 class="sub_title w10">CALL YOU</h2>
                        <div class="clearfix"></div>
                        <div class="login-form-1">
                            <form id="login-form" class="text-left">
                                <div class="login-form-main-message"></div>
                                <div class="main-login-form">
                                    <div class="login-group">
                                        <div class="form-group">
                                            <label for="ad" class="sr-only">Name</label>
                                            <input type="text" class="form-control" id="ad" name="ad" placeholder="Name">
                                        </div>
                                        <div class="form-group">
                                            <label for="tel" class="sr-only">Phone Number</label>
                                            <input type="text" class="form-control" id="tel" name="tel" placeholder="Phone Number">
                                        </div>
                                    </div>
                                    <button type="submit" class="login-button"><i class="fa fa-chevron-right"></i></button>
                                </div>
                            </form>
                        </div>                            
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>

<?php include 'backFolder/front_footer.php'; ?>