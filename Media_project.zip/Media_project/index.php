
<?php
include 'backFolder/front_header.php';
$obj_courses = new Course();
$selects = $obj_courses->selectedinfoby();
$obj_blog = new Blog();
$select = $obj_blog->selectedinfoby();
$boj_banner = new Banner();
$select_banner = $boj_banner->selectedinfoby();
$object_gallery = new Gallery();
$select_gallery = $object_gallery->selectedinfoby();
?>
<main class="site-main">
    <div class="sliders">
    <div id="myCarousel" class="carousel slide" data-ride="carousel">
        <!-- Indicators -->
        <ol class="carousel-indicators">
            <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
            <li data-target="#myCarousel" data-slide-to="1"></li>
            <li data-target="#myCarousel" data-slide-to="2"></li>
            <li data-target="#myCarousel" data-slide-to="3"></li>
        </ol>
        <!-- Wrapper for slides -->
        <div class="carousel-inner" role="listbox">
            <div class="item active">
                <img src="image/img-1.jpg" class="img-responsive" alt="Chania" style="width:100%; height:350px;">
            </div>
<?php while ($rows = mysqli_fetch_assoc($select_banner)) { ?> 
                <div class="item">

                    <img src="admin_classic/<?php echo $rows['banner_image']; ?>" class="img-responsive" alt="Chania" style="width:100%; height:350px;">

                </div>
<?php } ?> 
        </div>

        <!-- Left and right controls -->
        <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
            <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
            <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>
    </div>

    <section class="services boxes_area">
        <h2 class="section-title">Courses</h2>
        <p class="desc">Praesent faucibus ipsum at sodales blandit</p>
        <div class="container">
            <div class="row">
        <?php while ($rows = mysqli_fetch_assoc($selects)) { ?>
                    <div class="col-md-3 col-sm-6 col-xsx-6">
                        
                        <div class="serviceBox" style="">
                            <div class="service-icon">
                                <span><i class="fa fa-id-card-o"></i></span>
                            </div>
                            <div class="service-content">
                                <h3 class="title"><?php echo $rows['course_name']; ?></h3>
                                <a href="courses.php?id=<?php echo $rows['courses_id']; ?>" class="read-more fa fa-plus" data-toggle="tooltip" title="Read More"></a>
                            </div>
                        </div>
                        </div>
                   
                <?php } ?>

            </div>
        </div>
    </section>
    <section class="home-area">
        <div class="home_content">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12"><h2 class="sub_title">LATEST NEWS</h2></div>
                    <div class="home_list">
                        <ul>
    <?php while ($rows = mysqli_fetch_assoc($select)) { ?> 
                                <li class="col-md-3 col-sm-6 col-xs-12">
                                    <div class="thumbnail">
                                        <img src="admin_classic/<?php echo $rows['image']; ?>" alt="Post" style="width: 100%; height: 200px;">
                                        <div class="caption">
                                            <h3><a href="#"><?php echo $rows['title']; ?></a></h3>
                                            <p> <?php echo $rows['details']; ?> </p>
                                            <a href="#" class="btn btn-link" role="button">More</a>
                                        </div>
                                    </div>                                        
                                </li>
<?php } ?>
                                                              
                        </ul>
                    </div>

                    <div class="col-sm-9 home_bottom">
                        <h2 class="sub_title">REFERENCES</h2>
                        <div class="clearfix"></div>
                        <div class="row">
                            <div class="carousel slide" data-ride="carousel" data-type="multi" data-interval="6000" id="myCarousel">
                                <div class="carousel-inner">
                                    <div class="item active">
                                        <div class="col-md-2 col-sm-6 col-xs-12 p10">
                                            <a href="#"><img src="img/l1.jpg" class="img-responsive" alt="Reference"></a>
                                        </div>
                                    </div>
                                    <?php while ($rowses = mysqli_fetch_assoc($select_gallery)){?>
                                    <div class="item">
                                        <div class="col-md-2 col-sm-6 col-xs-12 p10">
                                            <a href="#"><img src="admin_classic/<?php echo $rowses['image']; ?>" class="img-responsive" alt="Reference"></a>
                                        </div>
                                    </div>
                                    <?php } ?>
                                    
                                    
                                  
                                   
                                   
                                    
                                    
                                    
                                    
                                   
                                    
                                    
                                                                         
                                </div>
                                <a class="left carousel-control" href="#myCarousel" data-slide="prev"><i class="glyphicon glyphicon-chevron-left"></i></a>
                                <a class="right carousel-control" href="#myCarousel" data-slide="next"><i class="glyphicon glyphicon-chevron-right"></i></a>
                            </div>
                        </div>                            
                    </div>
                    <div class="col-sm-3">
                        <h2 class="sub_title w10">CALL YOU</h2>
                        <div class="clearfix"></div>
                        <div class="login-form-1">
                            <form id="login-form" class="text-left">
                                <div class="login-form-main-message"></div>
                                <div class="main-login-form">
                                    <div class="login-group">
                                        <div class="form-group">
                                            <label for="ad" class="sr-only">Name</label>
                                            <input type="text" class="form-control" id="ad" name="ad" placeholder="Name">
                                        </div>
                                        <div class="form-group">
                                            <label for="tel" class="sr-only">Phone Number</label>
                                            <input type="text" class="form-control" id="tel" name="tel" placeholder="Phone Number">
                                        </div>
                                    </div>
                                    <button type="submit" class="login-button"><i class="fa fa-chevron-right"></i></button>
                                </div>
                            </form>
                        </div>                            
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>

<?php include 'backFolder/front_footer.php'; ?>